import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/App.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4cb492d2"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/App.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import "/src/styles/App.css";
import REPL from "/src/components/REPL.tsx";
import CommandRegistry from "/src/components/CommandRegistration.tsx";
import { mode } from "/src/functions/Mode.ts";
import { load } from "/src/functions/Load.ts";
import { view } from "/src/functions/View.ts";
import { broadband } from "/src/functions/Broadband.ts";
import { search } from "/src/functions/Search.ts";
import { mockload } from "/src/functions/MockLoad.ts";
import { mockview } from "/src/functions/MockView.ts";
import { mocksearch } from "/src/functions/MockSearch.ts";
import { DataProvider } from "/src/components/DataContext.tsx";
function App() {
  CommandRegistry.registerCommand("mode", mode);
  CommandRegistry.registerCommand("load_file", load);
  CommandRegistry.registerCommand("view", view);
  CommandRegistry.registerCommand("search", search);
  CommandRegistry.registerCommand("broadband", broadband);
  CommandRegistry.registerCommand("mock_load_file", mockload);
  CommandRegistry.registerCommand("mock_view", mockview);
  CommandRegistry.registerCommand("mock_search", mocksearch);
  return /* @__PURE__ */ jsxDEV(DataProvider, { children: /* @__PURE__ */ jsxDEV("div", { className: "App", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "App-header", children: /* @__PURE__ */ jsxDEV("h1", { "aria-label": "title", children: "Mock" }, void 0, false, {
      fileName: "/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/App.tsx",
      lineNumber: 31,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/App.tsx",
      lineNumber: 30,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(REPL, {}, void 0, false, {
      fileName: "/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/App.tsx",
      lineNumber: 33,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/App.tsx",
    lineNumber: 29,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/App.tsx",
    lineNumber: 28,
    columnNumber: 10
  }, this);
}
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/App.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0NVO0FBbENWLE9BQU8sb0JBQW1CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQzFCLE9BQU9BLFVBQVU7QUFDakIsT0FBT0MscUJBQXFCO0FBQzVCLFNBQVNDLFlBQVk7QUFDckIsU0FBU0MsWUFBWTtBQUNyQixTQUFTQyxZQUFZO0FBQ3JCLFNBQVNDLGlCQUFpQjtBQUMxQixTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLG9CQUFvQjtBQVM3QixTQUFTQyxNQUFNO0FBQ1hWLGtCQUFnQlcsZ0JBQWdCLFFBQVFWLElBQUk7QUFDNUNELGtCQUFnQlcsZ0JBQWdCLGFBQWFULElBQUk7QUFDakRGLGtCQUFnQlcsZ0JBQWdCLFFBQVFSLElBQUk7QUFDNUNILGtCQUFnQlcsZ0JBQWdCLFVBQVVOLE1BQU07QUFDaERMLGtCQUFnQlcsZ0JBQWdCLGFBQWFQLFNBQVM7QUFDdERKLGtCQUFnQlcsZ0JBQWdCLGtCQUFrQkwsUUFBUTtBQUMxRE4sa0JBQWdCVyxnQkFBZ0IsYUFBYUosUUFBUTtBQUNyRFAsa0JBQWdCVyxnQkFBZ0IsZUFBZUgsVUFBVTtBQUU3RCxTQUNJLHVCQUFDLGdCQUNDLGlDQUFDLFNBQUksV0FBVSxPQUNiO0FBQUEsMkJBQUMsU0FBSSxXQUFVLGNBQ2IsaUNBQUMsUUFBRyxjQUFXLFNBQVEsb0JBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMkIsS0FEN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFDQSx1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBSztBQUFBLE9BSlA7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUtBLEtBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQU9BO0FBRUo7QUFBQ0ksS0FwQlFGO0FBc0JULGVBQWVBO0FBQUksSUFBQUU7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlJFUEwiLCJDb21tYW5kUmVnaXN0cnkiLCJtb2RlIiwibG9hZCIsInZpZXciLCJicm9hZGJhbmQiLCJzZWFyY2giLCJtb2NrbG9hZCIsIm1vY2t2aWV3IiwibW9ja3NlYXJjaCIsIkRhdGFQcm92aWRlciIsIkFwcCIsInJlZ2lzdGVyQ29tbWFuZCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQXBwLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgXCIuLi9zdHlsZXMvQXBwLmNzc1wiO1xuaW1wb3J0IFJFUEwgZnJvbSBcIi4vUkVQTFwiO1xuaW1wb3J0IENvbW1hbmRSZWdpc3RyeSBmcm9tICcuL0NvbW1hbmRSZWdpc3RyYXRpb24nO1xuaW1wb3J0IHsgbW9kZSB9IGZyb20gXCIuLi9mdW5jdGlvbnMvTW9kZVwiO1xuaW1wb3J0IHsgbG9hZCB9IGZyb20gXCIuLi9mdW5jdGlvbnMvTG9hZFwiO1xuaW1wb3J0IHsgdmlldyB9IGZyb20gXCIuLi9mdW5jdGlvbnMvVmlld1wiO1xuaW1wb3J0IHsgYnJvYWRiYW5kIH0gZnJvbSBcIi4uL2Z1bmN0aW9ucy9Ccm9hZGJhbmRcIjtcbmltcG9ydCB7IHNlYXJjaCB9IGZyb20gXCIuLi9mdW5jdGlvbnMvU2VhcmNoXCI7XG5pbXBvcnQgeyBtb2NrbG9hZCB9IGZyb20gXCIuLi9mdW5jdGlvbnMvTW9ja0xvYWRcIjtcbmltcG9ydCB7IG1vY2t2aWV3IH0gZnJvbSBcIi4uL2Z1bmN0aW9ucy9Nb2NrVmlld1wiO1xuaW1wb3J0IHsgbW9ja3NlYXJjaCB9IGZyb20gXCIuLi9mdW5jdGlvbnMvTW9ja1NlYXJjaFwiO1xuaW1wb3J0IHsgRGF0YVByb3ZpZGVyIH0gZnJvbSAnLi9EYXRhQ29udGV4dCc7XG5cblxuXG4vKipcbiAqIFRoaXMgaXMgdGhlIGhpZ2hlc3QgbGV2ZWwgY29tcG9uZW50IVxuICogSXQgY29udGFpbnMgb3VyIFJFUEwgY29tcG9uZW50LCB3aGljaCBpcyB3aGVyZSBldmVyeXRoaW5nIGlzIGRpc3BsYXllZDogXG4gKiB0aGUgUkVQTEhpc3RvcnkgYW5kIHRoZSBSRVBMSW5wdXQgYXJlYXMhXG4gKi9cbmZ1bmN0aW9uIEFwcCgpIHtcbiAgICBDb21tYW5kUmVnaXN0cnkucmVnaXN0ZXJDb21tYW5kKCdtb2RlJywgbW9kZSk7XG4gICAgQ29tbWFuZFJlZ2lzdHJ5LnJlZ2lzdGVyQ29tbWFuZCgnbG9hZF9maWxlJywgbG9hZCk7XG4gICAgQ29tbWFuZFJlZ2lzdHJ5LnJlZ2lzdGVyQ29tbWFuZCgndmlldycsIHZpZXcpO1xuICAgIENvbW1hbmRSZWdpc3RyeS5yZWdpc3RlckNvbW1hbmQoJ3NlYXJjaCcsIHNlYXJjaCk7XG4gICAgQ29tbWFuZFJlZ2lzdHJ5LnJlZ2lzdGVyQ29tbWFuZCgnYnJvYWRiYW5kJywgYnJvYWRiYW5kKTtcbiAgICBDb21tYW5kUmVnaXN0cnkucmVnaXN0ZXJDb21tYW5kKCdtb2NrX2xvYWRfZmlsZScsIG1vY2tsb2FkKTtcbiAgICBDb21tYW5kUmVnaXN0cnkucmVnaXN0ZXJDb21tYW5kKCdtb2NrX3ZpZXcnLCBtb2Nrdmlldyk7XG4gICAgQ29tbWFuZFJlZ2lzdHJ5LnJlZ2lzdGVyQ29tbWFuZCgnbW9ja19zZWFyY2gnLCBtb2Nrc2VhcmNoKTtcblxucmV0dXJuIChcbiAgICA8RGF0YVByb3ZpZGVyPiBcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiQXBwXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiQXBwLWhlYWRlclwiPlxuICAgICAgICAgIDxoMSBhcmlhLWxhYmVsPVwidGl0bGVcIj5Nb2NrPC9oMT5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxSRVBMIC8+XG4gICAgICA8L2Rpdj5cbiAgICA8L0RhdGFQcm92aWRlcj4gXG4gICk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IEFwcDtcbiJdLCJmaWxlIjoiL1VzZXJzL2lsYW5hL0Rlc2t0b3AvQnJvd24vQ1MzMi9yZXBsLWluZ3V5ZW40LXRhaW5hMS9Gcm9udGVuZC9zcmMvY29tcG9uZW50cy9BcHAudHN4In0=