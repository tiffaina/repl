import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/REPL.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e8b8e43"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/REPL.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import "/src/styles/main.css";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=7e8b8e43"; const useState = __vite__cjsImport4_react["useState"];
import { REPLHistory } from "/src/components/REPLHistory.tsx";
import { REPLInput } from "/src/components/REPLInput.tsx";
export default function REPL() {
  _s();
  const [history, setHistory] = useState([]);
  const [mode, setMode] = useState("brief");
  return /* @__PURE__ */ jsxDEV("div", { className: "repl", children: [
    /* @__PURE__ */ jsxDEV(REPLHistory, { history, mode }, void 0, false, {
      fileName: "/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/REPL.tsx",
      lineNumber: 22,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("hr", {}, void 0, false, {
      fileName: "/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/REPL.tsx",
      lineNumber: 23,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(REPLInput, { history, mode, setHistory, setMode }, void 0, false, {
      fileName: "/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/REPL.tsx",
      lineNumber: 24,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/REPL.tsx",
    lineNumber: 21,
    columnNumber: 10
  }, this);
}
_s(REPL, "TcCpfk1zOIJDFU469MY6UboHu1E=");
_c = REPL;
var _c;
$RefreshReg$(_c, "REPL");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/REPL.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUJNOzs7Ozs7Ozs7Ozs7Ozs7OztBQXJCTixPQUFPO0FBQ1AsU0FBU0EsZ0JBQWdCO0FBQ3pCLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyxpQkFBaUI7QUFXMUIsd0JBQXdCQyxPQUFPO0FBQUFDLEtBQUE7QUFFN0IsUUFBTSxDQUFDQyxTQUFTQyxVQUFVLElBQUlOLFNBQW9CLEVBQUU7QUFDcEQsUUFBTSxDQUFDTyxNQUFNQyxPQUFPLElBQUlSLFNBQWlCLE9BQU87QUFFaEQsU0FDRSx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLDJCQUFDLGVBQVksU0FBa0IsUUFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwQztBQUFBLElBQzFDLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFJO0FBQUEsSUFDSix1QkFBQyxhQUNDLFNBQ0EsTUFDQSxZQUNBLFdBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUltQjtBQUFBLE9BUHJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FTQTtBQUVKO0FBQUNJLEdBakJ1QkQsTUFBSTtBQUFBTSxLQUFKTjtBQUFJLElBQUFNO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsIlJFUExIaXN0b3J5IiwiUkVQTElucHV0IiwiUkVQTCIsIl9zIiwiaGlzdG9yeSIsInNldEhpc3RvcnkiLCJtb2RlIiwic2V0TW9kZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUkVQTC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFwiLi4vc3R5bGVzL21haW4uY3NzXCI7XG5pbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgUkVQTEhpc3RvcnkgfSBmcm9tIFwiLi9SRVBMSGlzdG9yeVwiO1xuaW1wb3J0IHsgUkVQTElucHV0IH0gZnJvbSBcIi4vUkVQTElucHV0XCI7XG5pbXBvcnQgeyBDb21tYW5kIH0gZnJvbSBcIi4uL2Z1bmN0aW9ucy9Db21tYW5kXCI7XG5pbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5cbi8qKlxuICogVGhpcyBjb21wb25lbnQgaXMgY2FsbGVkIGFzIHBhcnQgb2YgdGhlIEFwcCBjb21wb25lbnQuXG4gKiBUaGUgY29tcG9uZW50IGVuY2xvc2VzIGJvdGggdGhlIFJFUExIaXN0b3J5IGNvbXBvbmVudCBhbmQgdGhlIFJFUExJbnB1dCBjb21wb25lbnQsXG4gKiB3aGljaCB0b2dldGhlciBkaXNwbGF5cyB0aGUgZnVsbCBzY3JlZW4gb2YgdGhlIGNvbW1hbmQgbG9nIGFuZCB0aGUgY29tbWFuZCBpbnB1dFxuICogYXJlYSBhdCB0aGUgYm90dG9tLlxuICogQHJldHVybnMgQW4gSFRNTCBkaXYgaW5jbHVkaW5nIGJvdGggUkVQTEhpc3RvcnkgYW5kIFJFUExJbnB1dCBjb21wb25lbnRzXG4gKi9cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFJFUEwoKSB7XG4gIC8vIFRoZXNlIGNvbnN0YW50cyBtYW5hZ2UgdGhlIHN0YXRlIHRoYXQgc3ViLWNvbXBvbmVudHMgaGF2ZSBhY2Nlc3MgdG9cbiAgY29uc3QgW2hpc3RvcnksIHNldEhpc3RvcnldID0gdXNlU3RhdGU8Q29tbWFuZFtdPihbXSk7XG4gIGNvbnN0IFttb2RlLCBzZXRNb2RlXSA9IHVzZVN0YXRlPHN0cmluZz4oXCJicmllZlwiKTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwicmVwbFwiPlxuICAgICAgPFJFUExIaXN0b3J5IGhpc3Rvcnk9e2hpc3Rvcnl9IG1vZGU9e21vZGV9IC8+XG4gICAgICA8aHI+PC9ocj5cbiAgICAgIDxSRVBMSW5wdXRcbiAgICAgICAgaGlzdG9yeT17aGlzdG9yeX1cbiAgICAgICAgbW9kZT17bW9kZX1cbiAgICAgICAgc2V0SGlzdG9yeT17c2V0SGlzdG9yeX1cbiAgICAgICAgc2V0TW9kZT17c2V0TW9kZX1cbiAgICAgIC8+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9pbGFuYS9EZXNrdG9wL0Jyb3duL0NTMzIvcmVwbC1pbmd1eWVuNC10YWluYTEvRnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvUkVQTC50c3gifQ==