import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ControlledInput.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e8b8e43"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/ControlledInput.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import "/src/styles/main.css";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=7e8b8e43"; const useEffect = __vite__cjsImport4_react["useEffect"]; const useRef = __vite__cjsImport4_react["useRef"];
export function ControlledInput(props) {
  _s();
  const inputRef = useRef(null);
  useEffect(() => {
    const handleKeyPress = (event) => {
      if (event.key === "i" && event.ctrlKey) {
        event.preventDefault();
        if (inputRef.current) {
          inputRef.current.focus();
        }
      }
    };
    window.addEventListener("keydown", handleKeyPress);
    return () => {
      window.removeEventListener("keydown", handleKeyPress);
    };
  }, []);
  return /* @__PURE__ */ jsxDEV("input", { ref: inputRef, type: "text", className: "repl-command-box", value: props.value, placeholder: "Enter command here! Press Ctrl + i to focus on the input box. Press Ctrl + o to focus on the output history.", onChange: (ev) => props.setValue(ev.target.value), "aria-label": props.ariaLabel }, void 0, false, {
    fileName: "/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/ControlledInput.tsx",
    lineNumber: 41,
    columnNumber: 10
  }, this);
}
_s(ControlledInput, "cBQ6FQ+sf5H+lvNONLKqtm4aeQ8=");
_c = ControlledInput;
var _c;
$RefreshReg$(_c, "ControlledInput");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/ControlledInput.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNENJOzs7Ozs7Ozs7Ozs7Ozs7OztBQTVDSixPQUFPO0FBRVAsU0FBU0EsV0FBV0MsY0FBYztBQXFCM0IsZ0JBQVNDLGdCQUFnQkMsT0FBNkI7QUFBQUMsS0FBQTtBQUMzRCxRQUFNQyxXQUFXSixPQUF5QixJQUFJO0FBRTlDRCxZQUFVLE1BQU07QUFDZCxVQUFNTSxpQkFBaUJBLENBQUNDLFVBQXlCO0FBQy9DLFVBQUlBLE1BQU1DLFFBQVEsT0FBT0QsTUFBTUUsU0FBUztBQUN0Q0YsY0FBTUcsZUFBZTtBQUNyQixZQUFJTCxTQUFTTSxTQUFTO0FBQ3BCTixtQkFBU00sUUFBUUMsTUFBTTtBQUFBLFFBQ3pCO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFFQUMsV0FBT0MsaUJBQWlCLFdBQVdSLGNBQWM7QUFFakQsV0FBTyxNQUFNO0FBQ1hPLGFBQU9FLG9CQUFvQixXQUFXVCxjQUFjO0FBQUEsSUFDdEQ7QUFBQSxFQUNGLEdBQUcsRUFBRTtBQUVMLFNBQ0UsdUJBQUMsV0FDQyxLQUFLRCxVQUNMLE1BQUssUUFDTCxXQUFVLG9CQUNWLE9BQU9GLE1BQU1hLE9BQ2IsYUFBWSxnSEFDWixVQUFXQyxRQUFPZCxNQUFNZSxTQUFTRCxHQUFHRSxPQUFPSCxLQUFLLEdBQ2hELGNBQVliLE1BQU1pQixhQVBwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBUUM7QUFFTDtBQUFDaEIsR0EvQmVGLGlCQUFlO0FBQUFtQixLQUFmbkI7QUFBZSxJQUFBbUI7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZVJlZiIsIkNvbnRyb2xsZWRJbnB1dCIsInByb3BzIiwiX3MiLCJpbnB1dFJlZiIsImhhbmRsZUtleVByZXNzIiwiZXZlbnQiLCJrZXkiLCJjdHJsS2V5IiwicHJldmVudERlZmF1bHQiLCJjdXJyZW50IiwiZm9jdXMiLCJ3aW5kb3ciLCJhZGRFdmVudExpc3RlbmVyIiwicmVtb3ZlRXZlbnRMaXN0ZW5lciIsInZhbHVlIiwiZXYiLCJzZXRWYWx1ZSIsInRhcmdldCIsImFyaWFMYWJlbCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQ29udHJvbGxlZElucHV0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgXCIuLi9zdHlsZXMvbWFpbi5jc3NcIjtcbmltcG9ydCB7IERpc3BhdGNoLCBTZXRTdGF0ZUFjdGlvbiB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VSZWYgfSBmcm9tICdyZWFjdCc7XG5cblxuLyoqXG4gKiBUaGVzZSBhcmUgdGhlIHByb3BzIGZvciB0aGUgQ29udHJvbGxlZElucHV0IGNvbXBvbmVudC5cbiAqIC0gdmFsdWUgaXMgdGhlIHZhbHVlIHRoYXQgaXMgZW50ZXJlZCBpbnRvIHRoZSBjb21tYW5kIGJveFxuICogLSBzZXRWYWx1ZSBpcyBhIGZ1bmN0aW9uIHRoYXQgYWxsb3dzIHRoZSBjYWxsZXIgdG8gdXBkYXRlIHZhbHVlXG4gKiAtIGFyaWFMYWJlbCBpcyB0aGUgbGFiZWwgZm9yIHRoZSBpbnB1dCB0aGF0IGFsbG93cyBwbGF5d3JpZ2h0IHRlc3RpbmdcbiAqL1xuaW50ZXJmYWNlIENvbnRyb2xsZWRJbnB1dFByb3BzIHtcbiAgdmFsdWU6IHN0cmluZztcbiAgc2V0VmFsdWU6IERpc3BhdGNoPFNldFN0YXRlQWN0aW9uPHN0cmluZz4+O1xuICBhcmlhTGFiZWw6IHN0cmluZztcbn1cblxuLyoqXG4gKiBUaGlzIGNvbXBvbmVudCBhbGxvd3MgdGhlIHVzZXIgdG8gdHlwZSB0aGVpciBpbnB1dCBpbnRvIHRoZSBjb21tYW5kIGJveCwgYW5kXG4gKiB1cGRhdGVzIHRoZSB2YXJpYWJsZSB2YWx1ZSBhcyB0aGUgdXNlciB0eXBlcy5cbiAqIEBwYXJhbSBwcm9wcyBpcyB0aGUgaW50ZXJmYWNlIGFib3ZlIGNvbnRhaW5pbmcgdGhlIGFyZ3VtZW50cyB0byBDb250cm9sbGVkSW5wdXRcbiAqIEByZXR1cm5zIGFuIEhUTUwgaW5wdXQgdGhhdCBzaG93cyBhbmQgdXBkYXRlcyB0aGUgdGV4dCB0aGF0IHRoZSB1c2VyIGhhcyBlbnRlcmVkXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBDb250cm9sbGVkSW5wdXQocHJvcHM6IENvbnRyb2xsZWRJbnB1dFByb3BzKSB7XG4gIGNvbnN0IGlucHV0UmVmID0gdXNlUmVmPEhUTUxJbnB1dEVsZW1lbnQ+KG51bGwpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgaGFuZGxlS2V5UHJlc3MgPSAoZXZlbnQ6IEtleWJvYXJkRXZlbnQpID0+IHtcbiAgICAgIGlmIChldmVudC5rZXkgPT09ICdpJyAmJiBldmVudC5jdHJsS2V5KSB7XG4gICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgIGlmIChpbnB1dFJlZi5jdXJyZW50KSB7XG4gICAgICAgICAgaW5wdXRSZWYuY3VycmVudC5mb2N1cygpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfTtcblxuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdrZXlkb3duJywgaGFuZGxlS2V5UHJlc3MpO1xuXG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKCdrZXlkb3duJywgaGFuZGxlS2V5UHJlc3MpO1xuICAgIH07XG4gIH0sIFtdKTtcblxuICByZXR1cm4gKFxuICAgIDxpbnB1dFxuICAgICAgcmVmPXtpbnB1dFJlZn1cbiAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgIGNsYXNzTmFtZT1cInJlcGwtY29tbWFuZC1ib3hcIlxuICAgICAgdmFsdWU9e3Byb3BzLnZhbHVlfVxuICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBjb21tYW5kIGhlcmUhIFByZXNzIEN0cmwgKyBpIHRvIGZvY3VzIG9uIHRoZSBpbnB1dCBib3guIFByZXNzIEN0cmwgKyBvIHRvIGZvY3VzIG9uIHRoZSBvdXRwdXQgaGlzdG9yeS5cIlxuICAgICAgb25DaGFuZ2U9eyhldikgPT4gcHJvcHMuc2V0VmFsdWUoZXYudGFyZ2V0LnZhbHVlKX1cbiAgICAgIGFyaWEtbGFiZWw9e3Byb3BzLmFyaWFMYWJlbH1cbiAgICA+PC9pbnB1dD5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2lsYW5hL0Rlc2t0b3AvQnJvd24vQ1MzMi9yZXBsLWluZ3V5ZW40LXRhaW5hMS9Gcm9udGVuZC9zcmMvY29tcG9uZW50cy9Db250cm9sbGVkSW5wdXQudHN4In0=