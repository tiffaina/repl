import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/App.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=77b65088"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/tiffneyaina/CS32/mock-jstifel1-taina1/mock/src/components/App.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import "/src/styles/App.css";
import REPL from "/src/components/REPL.tsx";
function App() {
  return /* @__PURE__ */ jsxDEV("div", { className: "App", children: [
    /* @__PURE__ */ jsxDEV("p", { className: "App-header", children: [
      /* @__PURE__ */ jsxDEV("h1", { children: "Mock" }, void 0, false, {
        fileName: "/Users/tiffneyaina/CS32/mock-jstifel1-taina1/mock/src/components/App.tsx",
        lineNumber: 10,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: " by jake stifelman + tiffney aina" }, void 0, false, {
        fileName: "/Users/tiffneyaina/CS32/mock-jstifel1-taina1/mock/src/components/App.tsx",
        lineNumber: 11,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/tiffneyaina/CS32/mock-jstifel1-taina1/mock/src/components/App.tsx",
      lineNumber: 9,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(REPL, {}, void 0, false, {
      fileName: "/Users/tiffneyaina/CS32/mock-jstifel1-taina1/mock/src/components/App.tsx",
      lineNumber: 13,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/tiffneyaina/CS32/mock-jstifel1-taina1/mock/src/components/App.tsx",
    lineNumber: 8,
    columnNumber: 10
  }, this);
}
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/tiffneyaina/CS32/mock-jstifel1-taina1/mock/src/components/App.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBVVE7QUFWUixPQUFPLG9CQUFtQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUMxQixPQUFPQSxVQUFVO0FBS2pCLFNBQVNDLE1BQU07QUFDYixTQUNFLHVCQUFDLFNBQUksV0FBVSxPQUNiO0FBQUEsMkJBQUMsT0FBRSxXQUFVLGNBQ1g7QUFBQSw2QkFBQyxRQUFHLG9CQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBUTtBQUFBLE1BQ1IsdUJBQUMsT0FBRSxpREFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9DO0FBQUEsU0FGdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsSUFDQSx1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBSztBQUFBLE9BTFA7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQU1BO0FBRUo7QUFBQ0MsS0FWUUQ7QUFZVCxlQUFlQTtBQUFJLElBQUFDO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJSRVBMIiwiQXBwIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJBcHAudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCAnLi4vc3R5bGVzL0FwcC5jc3MnO1xuaW1wb3J0IFJFUEwgZnJvbSAnLi9SRVBMJztcblxuLyoqXG4gKiBUaGlzIGlzIHRoZSBoaWdoZXN0IGxldmVsIGNvbXBvbmVudCFcbiAqL1xuZnVuY3Rpb24gQXBwKCkge1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiQXBwXCI+XG4gICAgICA8cCBjbGFzc05hbWU9XCJBcHAtaGVhZGVyXCI+XG4gICAgICAgIDxoMT5Nb2NrPC9oMT5cbiAgICAgICAgPHA+IGJ5IGpha2Ugc3RpZmVsbWFuICsgdGlmZm5leSBhaW5hPC9wPlxuICAgICAgPC9wPlxuICAgICAgPFJFUEwgLz4gICAgICBcbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgQXBwO1xuIl0sImZpbGUiOiIvVXNlcnMvdGlmZm5leWFpbmEvQ1MzMi9tb2NrLWpzdGlmZWwxLXRhaW5hMS9tb2NrL3NyYy9jb21wb25lbnRzL0FwcC50c3gifQ==