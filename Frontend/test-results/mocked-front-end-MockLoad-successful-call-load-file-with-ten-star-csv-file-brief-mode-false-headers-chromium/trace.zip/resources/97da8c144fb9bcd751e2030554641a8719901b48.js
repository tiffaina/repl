import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/REPLInput.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e8b8e43"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/REPLInput.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import "/src/styles/main.css";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=7e8b8e43"; const useState = __vite__cjsImport4_react["useState"];
import { ControlledInput } from "/src/components/ControlledInput.tsx";
import { Command } from "/src/functions/Command.ts";
import CommandRegistry from "/src/components/CommandRegistration.tsx";
import BackendStatus from "/src/components/SharedState.tsx";
export function REPLInput(props) {
  _s();
  const [commandString, setCommandString] = useState("");
  const [count, setCount] = useState(0);
  const [hasHeader, setHasHeader] = useState("");
  const [filepath, setFilepath] = useState("");
  let backendLoaded = BackendStatus.getBackendStatus();
  const handleKey = (e) => {
    if (e.key === "Enter") {
      if (!commandString) {
        return;
      }
      handleSubmit(commandString);
    }
  };
  function handleSubmit(commandString2) {
    let commandArr = commandString2.split(" ");
    let command = commandArr[0];
    let newCommand;
    commandArr.push(filepath);
    commandArr.push(hasHeader);
    let result = CommandRegistry.executeCommand(command, commandArr).then((result2) => {
      if (result2[0][0] === "Mode success!") {
        let newMode = props.mode === "brief" ? "verbose" : "brief";
        props.setMode(newMode);
      }
      if (result2[0].length === 2) {
        setFilepath(result2[0][1]);
      } else if (result2[0].length === 3) {
        setFilepath(result2[0][1]);
        setHasHeader(result2[0][2]);
      }
      newCommand = new Command(commandString2, result2[1], result2[0][0]);
      setCount(count + 1);
      props.setHistory([...props.history, newCommand]);
      setCommandString("");
    }).catch((error) => {
      console.error("Error occurred:", error);
      setCount(count + 1);
      newCommand = new Command(commandString2, [], "Error occurred:" + error);
      props.setHistory([...props.history, newCommand]);
      setCommandString("");
      BackendStatus.setStatus(false);
    });
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "repl-input", onKeyDown: handleKey, children: [
    /* @__PURE__ */ jsxDEV("fieldset", { children: [
      /* @__PURE__ */ jsxDEV("legend", { "aria-label": "legend", children: "Enter a command: mode, load_file <csv-file-path>, view, or search <column> <value>" }, void 0, false, {
        fileName: "/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/REPLInput.tsx",
        lineNumber: 95,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(ControlledInput, { value: commandString, setValue: setCommandString, ariaLabel: "Command input" }, void 0, false, {
        fileName: "/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/REPLInput.tsx",
        lineNumber: 99,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/REPLInput.tsx",
      lineNumber: 94,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
      fileName: "/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/REPLInput.tsx",
      lineNumber: 101,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("button", { onClick: () => handleSubmit(commandString), children: [
      "Submitted ",
      count,
      " times"
    ] }, void 0, true, {
      fileName: "/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/REPLInput.tsx",
      lineNumber: 102,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/REPLInput.tsx",
    lineNumber: 93,
    columnNumber: 10
  }, this);
}
_s(REPLInput, "Cx/BIks9RLyhneNz5VhxuTuCDHU=");
_c = REPLInput;
var _c;
$RefreshReg$(_c, "REPLInput");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/REPLInput.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0dROzs7Ozs7Ozs7Ozs7Ozs7OztBQXRHUixPQUFPO0FBQ1AsU0FBbUNBLGdCQUFnQjtBQUNuRCxTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0MsZUFBZTtBQUN4QixPQUFPQyxxQkFBcUI7QUFFNUIsT0FBT0MsbUJBQW1CO0FBMkJuQixnQkFBU0MsVUFBVUMsT0FBdUI7QUFBQUMsS0FBQTtBQUUvQyxRQUFNLENBQUNDLGVBQWVDLGdCQUFnQixJQUFJVCxTQUFpQixFQUFFO0FBQzdELFFBQU0sQ0FBQ1UsT0FBT0MsUUFBUSxJQUFJWCxTQUFpQixDQUFDO0FBQzVDLFFBQU0sQ0FBQ1ksV0FBV0MsWUFBWSxJQUFJYixTQUFpQixFQUFFO0FBQ3JELFFBQU0sQ0FBQ2MsVUFBVUMsV0FBVyxJQUFJZixTQUFpQixFQUFFO0FBQ25ELE1BQUlnQixnQkFBeUJaLGNBQWNhLGlCQUFpQjtBQUk1RCxRQUFNQyxZQUFZQSxDQUFDQyxNQUFXO0FBQzVCLFFBQUlBLEVBQUVDLFFBQVEsU0FBUztBQUNyQixVQUFJLENBQUNaLGVBQWU7QUFDbEI7QUFBQSxNQUNGO0FBQ0FhLG1CQUFhYixhQUFhO0FBQUEsSUFDNUI7QUFBQSxFQUNGO0FBSUEsV0FBU2EsYUFBYWIsZ0JBQXVCO0FBQzNDLFFBQUljLGFBQXVCZCxlQUFjZSxNQUFNLEdBQUc7QUFDbEQsUUFBSUMsVUFBa0JGLFdBQVcsQ0FBQztBQUNsQyxRQUFJRztBQUdKSCxlQUFXSSxLQUFLWixRQUFRO0FBQ3hCUSxlQUFXSSxLQUFLZCxTQUFTO0FBQ3pCLFFBQUllLFNBQVN4QixnQkFBZ0J5QixlQUFlSixTQUFTRixVQUFVLEVBQzlETyxLQUFLRixhQUFVO0FBQ2QsVUFBSUEsUUFBTyxDQUFDLEVBQUUsQ0FBQyxNQUFNLGlCQUFpQjtBQUNwQyxZQUFJRyxVQUFVeEIsTUFBTXlCLFNBQVMsVUFBVSxZQUFZO0FBQ25EekIsY0FBTTBCLFFBQVFGLE9BQU87QUFBQSxNQUN2QjtBQUNBLFVBQUdILFFBQU8sQ0FBQyxFQUFFTSxXQUFXLEdBQUc7QUFDekJsQixvQkFBWVksUUFBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQUEsTUFDMUIsV0FBV0EsUUFBTyxDQUFDLEVBQUVNLFdBQVcsR0FBRztBQUNqQ2xCLG9CQUFZWSxRQUFPLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDeEJkLHFCQUFhYyxRQUFPLENBQUMsRUFBRSxDQUFDLENBQUM7QUFBQSxNQUMzQjtBQUNBRixtQkFBYSxJQUFJdkIsUUFBUU0sZ0JBQWVtQixRQUFPLENBQUMsR0FBR0EsUUFBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQy9EaEIsZUFBU0QsUUFBUSxDQUFDO0FBQ2xCSixZQUFNNEIsV0FBVyxDQUFDLEdBQUc1QixNQUFNNkIsU0FBU1YsVUFBVSxDQUFDO0FBQy9DaEIsdUJBQWlCLEVBQUU7QUFBQSxJQUNyQixDQUFDLEVBRUEyQixNQUFNQyxXQUFTO0FBQ2hCQyxjQUFRRCxNQUFNLG1CQUFtQkEsS0FBSztBQUV0QzFCLGVBQVNELFFBQVEsQ0FBQztBQUNsQmUsbUJBQWEsSUFBSXZCLFFBQVFNLGdCQUFlLElBQUksb0JBQWtCNkIsS0FBSztBQUNuRS9CLFlBQU00QixXQUFXLENBQUMsR0FBRzVCLE1BQU02QixTQUFTVixVQUFVLENBQUM7QUFDL0NoQix1QkFBaUIsRUFBRTtBQUNuQkwsb0JBQWNtQyxVQUFVLEtBQUs7QUFBQSxJQUMvQixDQUFDO0FBQUEsRUFJRDtBQU9BLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLGNBQWEsV0FBV3JCLFdBQ3JDO0FBQUEsMkJBQUMsY0FDQztBQUFBLDZCQUFDLFlBQU8sY0FBVyxVQUFRLGtHQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLG1CQUNDLE9BQU9WLGVBQ1AsVUFBVUMsa0JBQ1YsV0FBVyxtQkFIYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRzZCO0FBQUEsU0FSL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVVBO0FBQUEsSUFDQSx1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBRztBQUFBLElBQ0gsdUJBQUMsWUFBTyxTQUFTLE1BQU1ZLGFBQWFiLGFBQWEsR0FBRTtBQUFBO0FBQUEsTUFDdENFO0FBQUFBLE1BQU07QUFBQSxTQURuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxPQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FnQkE7QUFFSjtBQUFDSCxHQXJGZUYsV0FBUztBQUFBbUMsS0FBVG5DO0FBQVMsSUFBQW1DO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsIkNvbnRyb2xsZWRJbnB1dCIsIkNvbW1hbmQiLCJDb21tYW5kUmVnaXN0cnkiLCJCYWNrZW5kU3RhdHVzIiwiUkVQTElucHV0IiwicHJvcHMiLCJfcyIsImNvbW1hbmRTdHJpbmciLCJzZXRDb21tYW5kU3RyaW5nIiwiY291bnQiLCJzZXRDb3VudCIsImhhc0hlYWRlciIsInNldEhhc0hlYWRlciIsImZpbGVwYXRoIiwic2V0RmlsZXBhdGgiLCJiYWNrZW5kTG9hZGVkIiwiZ2V0QmFja2VuZFN0YXR1cyIsImhhbmRsZUtleSIsImUiLCJrZXkiLCJoYW5kbGVTdWJtaXQiLCJjb21tYW5kQXJyIiwic3BsaXQiLCJjb21tYW5kIiwibmV3Q29tbWFuZCIsInB1c2giLCJyZXN1bHQiLCJleGVjdXRlQ29tbWFuZCIsInRoZW4iLCJuZXdNb2RlIiwibW9kZSIsInNldE1vZGUiLCJsZW5ndGgiLCJzZXRIaXN0b3J5IiwiaGlzdG9yeSIsImNhdGNoIiwiZXJyb3IiLCJjb25zb2xlIiwic2V0U3RhdHVzIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJSRVBMSW5wdXQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBcIi4uL3N0eWxlcy9tYWluLmNzc1wiO1xuaW1wb3J0IHsgRGlzcGF0Y2gsIFNldFN0YXRlQWN0aW9uLCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgQ29udHJvbGxlZElucHV0IH0gZnJvbSBcIi4vQ29udHJvbGxlZElucHV0XCI7XG5pbXBvcnQgeyBDb21tYW5kIH0gZnJvbSBcIi4uL2Z1bmN0aW9ucy9Db21tYW5kXCI7XG5pbXBvcnQgQ29tbWFuZFJlZ2lzdHJ5IGZyb20gJy4vQ29tbWFuZFJlZ2lzdHJhdGlvbic7XG5pbXBvcnQgeyB1c2VEYXRhQ29udGV4dCB9IGZyb20gJy4vRGF0YUNvbnRleHQnO1xuaW1wb3J0IEJhY2tlbmRTdGF0dXMgZnJvbSAnLi9TaGFyZWRTdGF0ZSc7XG5cblxuXG4vKipcbiAqIFRoZXNlIGFyZSB0aGUgcHJvcHMgZm9yIHRoZSBSRVBMSW5wdXQgY29tcG9uZW50LlxuICogLSBoaXN0b3J5IGlzIGEgbGlzdCBvZiBhbGwgY29tbWFuZHMgdGhhdCBoYXZlIGJlZW4gcHVzaGVkIGJ5IHRoZSB1c2VyIGluIHRoaXMgc2Vzc2lvblxuICogLSBtb2RlIGlzIGEgYm9vbGVhbiBzZXQgdG8gdHJ1ZSBpZiBpbiBicmllZiBtb2RlIChkZWZhdWx0KSwgYW5kIGZhbHNlIGluIHZlcmJvc2UgbW9kZVxuICogLSBzZXRIaXN0b3J5IGlzIGEgZnVuY3Rpb24gdGhhdCBhbGxvd3MgdGhlIGNhbGxlciB0byBzZXQgdGhlIHZhbHVlIG9mIHRoZSBoaXN0b3J5IGFycmF5XG4gKiAtIHNldE1vZGUgaXMgYSBmdW5jdGlvbiB0aGF0IGFsbG93cyB0aGUgY2FsbGVyIHRvIHNldCB0aGUgdmFsdWUgb2YgbW9kZVxuICovXG5pbnRlcmZhY2UgUkVQTElucHV0UHJvcHMge1xuICBoaXN0b3J5OiBDb21tYW5kW107XG4gIG1vZGU6IHN0cmluZztcbiAgc2V0SGlzdG9yeTogRGlzcGF0Y2g8U2V0U3RhdGVBY3Rpb248Q29tbWFuZFtdPj47XG4gIHNldE1vZGU6IERpc3BhdGNoPFNldFN0YXRlQWN0aW9uPHN0cmluZz4+O1xufVxuXG4vKipcbiAqIFRoaXMgY29tcG9uZW50IGlzIGNhbGxlZCBhcyBwYXJ0IG9mIHRoZSBSRVBMIGNvbXBvbmVudC5cbiAqIFRoZSBSRVBMSW5wdXQgY29tcG9uZW50IHVzZXMgYSB0ZXh0IGlucHV0IGJhciBhbmQgYSBzdWJtaXQgYnV0dG9uIHRvIGFsbG93IHRoZSB1c2VyXG4gKiB0byBlbnRlciBjb21tYW5kcyBpbiB0aGUgaW5wdXQgYm94IGFuZCBzZW5kIHRoZW0gd2l0aCB0aGUgc3VibWl0IGJ1dHRvbi4gVGhlIFJFUExIaXN0b3J5XG4gKiBjb21wb25lbnQgaXMgdXBkYXRlZCBhY2NvcmRpbmcgdG8gdGhlIHJlc3VsdHMgb2YgdGhlc2UgY29tbWFuZHMuXG4gKiBWYWxpZCBjb21tYW5kcyBpbmNsdWRlIG1vZGUsIGxvYWRfZmlsZSA8Y3N2LWZpbGUtcGF0aD4sIHZpZXcsIGFuZCBzZWFyY2ggPGNvbHVtbj4gPHZhbHVlPlxuICogQHBhcmFtIHByb3BzIGlzIHRoZSBpbnRlcmZhY2UgYWJvdmUgY29udGFpbmluZyB0aGUgYXJndW1lbnRzIHRvIFJFUExJbnB1dFxuICogQHJldHVybnMgSFRNTCBkaXYgcmVwcmVzZW50aW5nIGlucHV0IGFyZWEsIHdpdGggaW5wdXQgYm94IGFuZCBzdWJtaXQgYnV0dG9uXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBSRVBMSW5wdXQocHJvcHM6IFJFUExJbnB1dFByb3BzKSB7XG4gIC8vIFRoZXNlIGNvbnN0YW50cyBtYW5hZ2UgdGhlIHN0YXRlIHRoYXQgc3ViLWNvbXBvbmVudHMgaGF2ZSBhY2Nlc3MgdG9cbiAgY29uc3QgW2NvbW1hbmRTdHJpbmcsIHNldENvbW1hbmRTdHJpbmddID0gdXNlU3RhdGU8c3RyaW5nPihcIlwiKTtcbiAgY29uc3QgW2NvdW50LCBzZXRDb3VudF0gPSB1c2VTdGF0ZTxudW1iZXI+KDApO1xuICBjb25zdCBbaGFzSGVhZGVyLCBzZXRIYXNIZWFkZXJdID0gdXNlU3RhdGU8c3RyaW5nPihcIlwiKTtcbiAgY29uc3QgW2ZpbGVwYXRoLCBzZXRGaWxlcGF0aF0gPSB1c2VTdGF0ZTxzdHJpbmc+KFwiXCIpO1xuICBsZXQgYmFja2VuZExvYWRlZDogYm9vbGVhbiA9IEJhY2tlbmRTdGF0dXMuZ2V0QmFja2VuZFN0YXR1cygpO1xuICBcblxuICAvLyBUaGlzIGZ1bmN0aW9uIGVuYWJsZXMgdGhlIGNvbW1hbmQgdG8gYmUgc2VudCB3aGVuIHRoZSByZXR1cm4ga2V5IGlzIHByZXNzZWQuXG4gIGNvbnN0IGhhbmRsZUtleSA9IChlOiBhbnkpID0+IHtcbiAgICBpZiAoZS5rZXkgPT09IFwiRW50ZXJcIikge1xuICAgICAgaWYgKCFjb21tYW5kU3RyaW5nKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGhhbmRsZVN1Ym1pdChjb21tYW5kU3RyaW5nKTtcbiAgICB9XG4gIH07XG5cbiAgLy8gVGhpcyBmdW5jdGlvbiBpcyB0cmlnZ2VyZWQgd2hlbiB0aGUgYnV0dG9uIGlzIGNsaWNrZWRcbiAgLy8gSXQgZGVwZW5kaW5nIG9uIHRoZSBjb21tYW5kIHRleHQsIGl0IGNyZWF0ZXMgYSBDb21tYW5kIG9iamVjdFxuICBmdW5jdGlvbiBoYW5kbGVTdWJtaXQoY29tbWFuZFN0cmluZzogc3RyaW5nKSB7XG4gICAgbGV0IGNvbW1hbmRBcnI6IHN0cmluZ1tdID0gY29tbWFuZFN0cmluZy5zcGxpdChcIiBcIik7XG4gICAgbGV0IGNvbW1hbmQ6IHN0cmluZyA9IGNvbW1hbmRBcnJbMF07XG4gICAgbGV0IG5ld0NvbW1hbmQ6IENvbW1hbmQ7XG5cbiAgICAvLyBnZXQgbWFwcGVkIGNvbW1hbmQgZnVuY3Rpb24gYW5kIGV4ZWN1dGUgaXRcbiAgICBjb21tYW5kQXJyLnB1c2goZmlsZXBhdGgpIC8vIGFkZCBmaWxlcGF0aCBpbnRvIGFyZ3NcbiAgICBjb21tYW5kQXJyLnB1c2goaGFzSGVhZGVyKSAvLyBhZGQgaGFzSGVhZGVyIGludG8gYXJnc1xuICAgIGxldCByZXN1bHQgPSBDb21tYW5kUmVnaXN0cnkuZXhlY3V0ZUNvbW1hbmQoY29tbWFuZCwgY29tbWFuZEFycilcbiAgICAudGhlbihyZXN1bHQgPT4ge1xuICAgICAgaWYgKHJlc3VsdFswXVswXSA9PT0gXCJNb2RlIHN1Y2Nlc3MhXCIpIHtcbiAgICAgICAgbGV0IG5ld01vZGUgPSBwcm9wcy5tb2RlID09PSBcImJyaWVmXCIgPyBcInZlcmJvc2VcIiA6IFwiYnJpZWZcIjtcbiAgICAgICAgcHJvcHMuc2V0TW9kZShuZXdNb2RlKTtcbiAgICAgIH0gXG4gICAgICBpZihyZXN1bHRbMF0ubGVuZ3RoID09PSAyKSB7XG4gICAgICAgIHNldEZpbGVwYXRoKHJlc3VsdFswXVsxXSk7XG4gICAgICB9IGVsc2UgaWYgKHJlc3VsdFswXS5sZW5ndGggPT09IDMpIHtcbiAgICAgICAgc2V0RmlsZXBhdGgocmVzdWx0WzBdWzFdKTtcbiAgICAgICAgc2V0SGFzSGVhZGVyKHJlc3VsdFswXVsyXSk7XG4gICAgICB9XG4gICAgICBuZXdDb21tYW5kID0gbmV3IENvbW1hbmQoY29tbWFuZFN0cmluZywgcmVzdWx0WzFdLCByZXN1bHRbMF1bMF0pO1xuICAgICAgc2V0Q291bnQoY291bnQgKyAxKTtcbiAgICAgIHByb3BzLnNldEhpc3RvcnkoWy4uLnByb3BzLmhpc3RvcnksIG5ld0NvbW1hbmRdKTtcbiAgICAgIHNldENvbW1hbmRTdHJpbmcoXCJcIik7XG4gICAgfSlcbiAgICBcbiAgICAuY2F0Y2goZXJyb3IgPT4ge1xuICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBvY2N1cnJlZDpcIiwgZXJyb3IpO1xuICAgIC8vIEhhbmRsZSB0aGUgZXJyb3IsIGUuZy4sIHVwZGF0ZSB0aGUgVUkgdG8gc2hvdyBhbiBlcnJvciBtZXNzYWdlLlxuICAgIHNldENvdW50KGNvdW50ICsgMSk7XG4gICAgbmV3Q29tbWFuZCA9IG5ldyBDb21tYW5kKGNvbW1hbmRTdHJpbmcsIFtdLCBcIkVycm9yIG9jY3VycmVkOlwiK2Vycm9yKTtcbiAgICBwcm9wcy5zZXRIaXN0b3J5KFsuLi5wcm9wcy5oaXN0b3J5LCBuZXdDb21tYW5kXSk7XG4gICAgc2V0Q29tbWFuZFN0cmluZyhcIlwiKTtcbiAgICBCYWNrZW5kU3RhdHVzLnNldFN0YXR1cyhmYWxzZSlcbiAgfSk7XG5cbiAgICBcbiAgICBcbiAgfVxuXG4gIC8qKlxuICAgKiBUaGlzIHJldHVybnMgdGhlIGxlZ2VuZCwgaW5wdXQgYm94LCBhbmQgc3VibWl0IGJ1dHRvbiB0aGF0IGFsbG93IHRoZSB1c2VyIHRvXG4gICAqIHNlbmQgY29tbWFuZHMgYW5kIHVwZGF0ZSB0aGUgYXBwJ3Mgc3RhdGUsIHNvIHRoYXQgY29tbWFuZHMgY2FuIGJlIGRpc3BsYXllZCBieVxuICAgKiB0aGUgUkVQTEhpc3RvcnkgY29tcG9uZW50LlxuICAgKi9cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInJlcGwtaW5wdXRcIiBvbktleURvd249e2hhbmRsZUtleX0+XG4gICAgICA8ZmllbGRzZXQ+XG4gICAgICAgIDxsZWdlbmQgYXJpYS1sYWJlbD1cImxlZ2VuZFwiPlxuICAgICAgICAgIEVudGVyIGEgY29tbWFuZDogbW9kZSwgbG9hZF9maWxlICZsdDtjc3YtZmlsZS1wYXRoJmd0Oywgdmlldywgb3JcbiAgICAgICAgICBzZWFyY2ggJmx0O2NvbHVtbiZndDsgJmx0O3ZhbHVlJmd0O1xuICAgICAgICA8L2xlZ2VuZD5cbiAgICAgICAgPENvbnRyb2xsZWRJbnB1dFxuICAgICAgICAgIHZhbHVlPXtjb21tYW5kU3RyaW5nfVxuICAgICAgICAgIHNldFZhbHVlPXtzZXRDb21tYW5kU3RyaW5nfVxuICAgICAgICAgIGFyaWFMYWJlbD17XCJDb21tYW5kIGlucHV0XCJ9XG4gICAgICAgIC8+XG4gICAgICA8L2ZpZWxkc2V0PlxuICAgICAgPGJyIC8+XG4gICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IGhhbmRsZVN1Ym1pdChjb21tYW5kU3RyaW5nKX0+XG4gICAgICAgIFN1Ym1pdHRlZCB7Y291bnR9IHRpbWVzXG4gICAgICA8L2J1dHRvbj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2lsYW5hL0Rlc2t0b3AvQnJvd24vQ1MzMi9yZXBsLWluZ3V5ZW40LXRhaW5hMS9Gcm9udGVuZC9zcmMvY29tcG9uZW50cy9SRVBMSW5wdXQudHN4In0=