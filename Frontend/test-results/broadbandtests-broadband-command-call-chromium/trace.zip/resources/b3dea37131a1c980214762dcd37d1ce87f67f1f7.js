import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/REPLHistory.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=77b65088"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/tiffneyaina/CS32/mock-jstifel1-taina1/mock/src/components/REPLHistory.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import "/src/styles/main.css";
function makeHTMLTable(myArray) {
  return /* @__PURE__ */ jsxDEV("table", { className: "centered-table", children: /* @__PURE__ */ jsxDEV("tbody", { children: myArray.map((row, rowIndex) => /* @__PURE__ */ jsxDEV("tr", { children: row.map((cell, cellIndex) => /* @__PURE__ */ jsxDEV("td", { className: "table-cell", children: cell }, cellIndex, false, {
    fileName: "/Users/tiffneyaina/CS32/mock-jstifel1-taina1/mock/src/components/REPLHistory.tsx",
    lineNumber: 17,
    columnNumber: 45
  }, this)) }, rowIndex, false, {
    fileName: "/Users/tiffneyaina/CS32/mock-jstifel1-taina1/mock/src/components/REPLHistory.tsx",
    lineNumber: 16,
    columnNumber: 43
  }, this)) }, void 0, false, {
    fileName: "/Users/tiffneyaina/CS32/mock-jstifel1-taina1/mock/src/components/REPLHistory.tsx",
    lineNumber: 15,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "/Users/tiffneyaina/CS32/mock-jstifel1-taina1/mock/src/components/REPLHistory.tsx",
    lineNumber: 14,
    columnNumber: 10
  }, this);
}
export function REPLHistory(props) {
  if (props.outputMode == "verbose") {
    return /* @__PURE__ */ jsxDEV("div", { className: "repl-history", children: props.history.map((item, index) => /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        "Command: ",
        item.command
      ] }, void 0, true, {
        fileName: "/Users/tiffneyaina/CS32/mock-jstifel1-taina1/mock/src/components/REPLHistory.tsx",
        lineNumber: 30,
        columnNumber: 25
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        "Result: ",
        makeHTMLTable(item.result)
      ] }, void 0, true, {
        fileName: "/Users/tiffneyaina/CS32/mock-jstifel1-taina1/mock/src/components/REPLHistory.tsx",
        lineNumber: 33,
        columnNumber: 25
      }, this),
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "/Users/tiffneyaina/CS32/mock-jstifel1-taina1/mock/src/components/REPLHistory.tsx",
        lineNumber: 36,
        columnNumber: 25
      }, this),
      /* @__PURE__ */ jsxDEV("hr", { className: "output-separator" }, void 0, false, {
        fileName: "/Users/tiffneyaina/CS32/mock-jstifel1-taina1/mock/src/components/REPLHistory.tsx",
        lineNumber: 37,
        columnNumber: 25
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/tiffneyaina/CS32/mock-jstifel1-taina1/mock/src/components/REPLHistory.tsx",
      lineNumber: 29,
      columnNumber: 53
    }, this)) }, void 0, false, {
      fileName: "/Users/tiffneyaina/CS32/mock-jstifel1-taina1/mock/src/components/REPLHistory.tsx",
      lineNumber: 25,
      columnNumber: 12
    }, this);
  } else {
    return /* @__PURE__ */ jsxDEV("div", { className: "repl-history", children: props.history.map((item, index) => /* @__PURE__ */ jsxDEV("div", { children: [
      "Result: ",
      makeHTMLTable(item.result),
      /* @__PURE__ */ jsxDEV("hr", { className: "output-separator" }, void 0, false, {
        fileName: "/Users/tiffneyaina/CS32/mock-jstifel1-taina1/mock/src/components/REPLHistory.tsx",
        lineNumber: 47,
        columnNumber: 25
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/tiffneyaina/CS32/mock-jstifel1-taina1/mock/src/components/REPLHistory.tsx",
      lineNumber: 45,
      columnNumber: 53
    }, this)) }, void 0, false, {
      fileName: "/Users/tiffneyaina/CS32/mock-jstifel1-taina1/mock/src/components/REPLHistory.tsx",
      lineNumber: 41,
      columnNumber: 12
    }, this);
  }
}
_c = REPLHistory;
var _c;
$RefreshReg$(_c, "REPLHistory");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/tiffneyaina/CS32/mock-jstifel1-taina1/mock/src/components/REPLHistory.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0JnQjtBQXBCaEIsT0FBTyxvQkFBb0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFhM0IsU0FBU0EsY0FBY0MsU0FBcUI7QUFDeEMsU0FDRSx1QkFBQyxXQUFNLFdBQVUsa0JBQ2YsaUNBQUMsV0FDRUEsa0JBQVFDLElBQUksQ0FBQ0MsS0FBS0MsYUFDakIsdUJBQUMsUUFDRUQsY0FBSUQsSUFBSSxDQUFDRyxNQUFNQyxjQUNkLHVCQUFDLFFBQW1CLFdBQVUsY0FBY0Qsa0JBQW5DQyxXQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBaUQsQ0FDbEQsS0FITUYsVUFBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBSUEsQ0FDRCxLQVBIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FRQSxLQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FVQTtBQUVKO0FBRUssZ0JBQVNHLFlBQVlDLE9BQTBCO0FBQ2xELE1BQUdBLE1BQU1DLGNBQWMsV0FBVztBQUM5QixXQUNJLHVCQUFDLFNBQUksV0FBVSxnQkFJVkQsZ0JBQU1FLFFBQVFSLElBQUksQ0FBQ1MsTUFBTUMsVUFDdEIsdUJBQUMsU0FDRztBQUFBLDZCQUFDLFNBQUc7QUFBQTtBQUFBLFFBQ1VELEtBQUtFO0FBQUFBLFdBRG5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsU0FBRztBQUFBO0FBQUEsUUFDU2IsY0FBY1csS0FBS0csTUFBTTtBQUFBLFdBRHRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQUc7QUFBQSxNQUNILHVCQUFDLFFBQUcsV0FBVSxzQkFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdDO0FBQUEsU0FScEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVNBLENBQ0gsS0FmTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZ0JBO0FBQUEsRUFFUixPQUFPO0FBQ0gsV0FDSSx1QkFBQyxTQUFJLFdBQVUsZ0JBSVZOLGdCQUFNRSxRQUFRUixJQUFJLENBQUNTLE1BQU1DLFVBQ3RCLHVCQUFDLFNBQUc7QUFBQTtBQUFBLE1BQ1NaLGNBQWNXLEtBQUtHLE1BQU07QUFBQSxNQUNsQyx1QkFBQyxRQUFHLFdBQVUsc0JBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnQztBQUFBLFNBRnBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQSxDQUNILEtBVEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVVBO0FBQUEsRUFFUDtBQUNMO0FBQUNDLEtBcENlUjtBQUFXLElBQUFRO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJtYWtlSFRNTFRhYmxlIiwibXlBcnJheSIsIm1hcCIsInJvdyIsInJvd0luZGV4IiwiY2VsbCIsImNlbGxJbmRleCIsIlJFUExIaXN0b3J5IiwicHJvcHMiLCJvdXRwdXRNb2RlIiwiaGlzdG9yeSIsIml0ZW0iLCJpbmRleCIsImNvbW1hbmQiLCJyZXN1bHQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlJFUExIaXN0b3J5LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgJy4uL3N0eWxlcy9tYWluLmNzcyc7XG5cbmludGVyZmFjZSBIaXN0b3J5T2JqZWN0IHtcbiAgICBjb21tYW5kOiBzdHJpbmc7XG4gICAgcmVzdWx0OiBzdHJpbmdbXVtdO1xuICB9XG5pbnRlcmZhY2UgUkVQTEhpc3RvcnlQcm9wc3tcbiAgICAvLyBUT0RPOiBGaWxsIHdpdGggc29tZSBzaGFyZWQgc3RhdGUgdHJhY2tpbmcgYWxsIHRoZSBwdXNoZWQgY29tbWFuZHNcbiAgICAvLyBDSEFOR0VEXG4gICAgaGlzdG9yeTogSGlzdG9yeU9iamVjdFtdXG4gICAgb3V0cHV0TW9kZTogc3RyaW5nO1xufVxuLy8gVHVybiBhbGwgaGlzdG9yeSBlbGVtZW50cyBpbnRvIGFuIGh0bWwgdGFibGVcbmZ1bmN0aW9uIG1ha2VIVE1MVGFibGUobXlBcnJheTogc3RyaW5nW11bXSkge1xuICAgIHJldHVybiAoXG4gICAgICA8dGFibGUgY2xhc3NOYW1lPSdjZW50ZXJlZC10YWJsZSc+XG4gICAgICAgIDx0Ym9keT5cbiAgICAgICAgICB7bXlBcnJheS5tYXAoKHJvdywgcm93SW5kZXgpID0+IChcbiAgICAgICAgICAgIDx0ciBrZXk9e3Jvd0luZGV4fT5cbiAgICAgICAgICAgICAge3Jvdy5tYXAoKGNlbGwsIGNlbGxJbmRleCkgPT4gKFxuICAgICAgICAgICAgICAgIDx0ZCBrZXk9e2NlbGxJbmRleH0gY2xhc3NOYW1lPSd0YWJsZS1jZWxsJz57Y2VsbH08L3RkPlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgKSl9XG4gICAgICAgIDwvdGJvZHk+XG4gICAgICA8L3RhYmxlPlxuICAgICk7XG4gIH1cbiAgLy9HZW5lcmF0ZSBIaXN0b3J5XG5leHBvcnQgZnVuY3Rpb24gUkVQTEhpc3RvcnkocHJvcHMgOiBSRVBMSGlzdG9yeVByb3BzKSB7XG4gICAgaWYocHJvcHMub3V0cHV0TW9kZSA9PSBcInZlcmJvc2VcIikge1xuICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZXBsLWhpc3RvcnlcIj5cbiAgICAgICAgICAgICAgICB7LyogVGhpcyBpcyB3aGVyZSBjb21tYW5kIGhpc3Rvcnkgd2lsbCBnbyAqL31cbiAgICAgICAgICAgICAgICB7LyogVE9ETzogVG8gZ28gdGhyb3VnaCBhbGwgdGhlIHB1c2hlZCBjb21tYW5kcy4uLiB0cnkgdGhlIC5tYXAoKSBmdW5jdGlvbiEgKi99XG4gICAgICAgICAgICAgICAgey8qIENIQU5HRUQgKi99XG4gICAgICAgICAgICAgICAge3Byb3BzLmhpc3RvcnkubWFwKChpdGVtLCBpbmRleCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBDb21tYW5kOiB7aXRlbS5jb21tYW5kfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFJlc3VsdDoge21ha2VIVE1MVGFibGUoaXRlbS5yZXN1bHQpfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8YnIgLz4gXG4gICAgICAgICAgICAgICAgICAgICAgICA8aHIgY2xhc3NOYW1lPVwib3V0cHV0LXNlcGFyYXRvclwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICk7XG4gICAgfSBlbHNlIHtcbiAgICAgICAgcmV0dXJuKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZXBsLWhpc3RvcnlcIj5cbiAgICAgICAgICAgICAgICB7LyogVGhpcyBpcyB3aGVyZSBjb21tYW5kIGhpc3Rvcnkgd2lsbCBnbyAqL31cbiAgICAgICAgICAgICAgICB7LyogVE9ETzogVG8gZ28gdGhyb3VnaCBhbGwgdGhlIHB1c2hlZCBjb21tYW5kcy4uLiB0cnkgdGhlIC5tYXAoKSBmdW5jdGlvbiEgKi99XG4gICAgICAgICAgICAgICAgey8qIENIQU5HRUQgKi99XG4gICAgICAgICAgICAgICAge3Byb3BzLmhpc3RvcnkubWFwKChpdGVtLCBpbmRleCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgUmVzdWx0OiB7bWFrZUhUTUxUYWJsZShpdGVtLnJlc3VsdCl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8aHIgY2xhc3NOYW1lPVwib3V0cHV0LXNlcGFyYXRvclwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICk7XG4gICAgIH1cbn0iXSwiZmlsZSI6Ii9Vc2Vycy90aWZmbmV5YWluYS9DUzMyL21vY2stanN0aWZlbDEtdGFpbmExL21vY2svc3JjL2NvbXBvbmVudHMvUkVQTEhpc3RvcnkudHN4In0=