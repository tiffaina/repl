import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/REPLInput.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4c1ef5d8"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/REPLInput.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import "/src/styles/main.css";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=4c1ef5d8"; const useState = __vite__cjsImport4_react["useState"];
import { ControlledInput } from "/src/components/ControlledInput.tsx";
import { Command } from "/src/functions/Command.ts";
import CommandRegistry from "/src/components/CommandRegistration.tsx";
export function REPLInput(props) {
  _s();
  const [commandString, setCommandString] = useState("");
  const [count, setCount] = useState(0);
  const handleKey = (e) => {
    if (e.key === "Enter") {
      if (!commandString) {
        return;
      }
      handleSubmit(commandString);
    }
  };
  function handleSubmit(commandString2) {
    let commandArr = commandString2.split(" ");
    let command = commandArr[0];
    let newCommand;
    let result = CommandRegistry.executeCommand(command, commandArr).then((result2) => {
      if (result2[0] === "Mode success!") {
        let newMode = props.mode === "brief" ? "verbose" : "brief";
        props.setMode(newMode);
      }
      newCommand = new Command(commandString2, result2[1], result2[0]);
      setCount(count + 1);
      props.setHistory([...props.history, newCommand]);
      setCommandString("");
    }).catch((error) => {
      console.error("Error occurred:", error);
      setCount(count + 1);
      newCommand = new Command(commandString2, [], "Error occurred:" + error);
      props.setHistory([...props.history, newCommand]);
      setCommandString("");
    });
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "repl-input", onKeyDown: handleKey, children: [
    /* @__PURE__ */ jsxDEV("fieldset", { children: [
      /* @__PURE__ */ jsxDEV("legend", { "aria-label": "legend", children: "Enter a command: mode, load_file <csv-file-path>, view, or search <column> <value>" }, void 0, false, {
        fileName: "/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/REPLInput.tsx",
        lineNumber: 82,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(ControlledInput, { value: commandString, setValue: setCommandString, ariaLabel: "Command input" }, void 0, false, {
        fileName: "/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/REPLInput.tsx",
        lineNumber: 86,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/REPLInput.tsx",
      lineNumber: 81,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
      fileName: "/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/REPLInput.tsx",
      lineNumber: 88,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("button", { onClick: () => handleSubmit(commandString), children: [
      "Submitted ",
      count,
      " times"
    ] }, void 0, true, {
      fileName: "/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/REPLInput.tsx",
      lineNumber: 89,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/REPLInput.tsx",
    lineNumber: 80,
    columnNumber: 10
  }, this);
}
_s(REPLInput, "ypBeywyVo+2PY5emNoTBEHjbBQk=");
_c = REPLInput;
var _c;
$RefreshReg$(_c, "REPLInput");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/REPLInput.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0ZROzs7Ozs7Ozs7Ozs7Ozs7OztBQXRGUixPQUFPO0FBQ1AsU0FBbUNBLGdCQUFnQjtBQUNuRCxTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0MsZUFBZTtBQUN4QixPQUFPQyxxQkFBcUI7QUF5QnJCLGdCQUFTQyxVQUFVQyxPQUF1QjtBQUFBQyxLQUFBO0FBRS9DLFFBQU0sQ0FBQ0MsZUFBZUMsZ0JBQWdCLElBQUlSLFNBQWlCLEVBQUU7QUFDN0QsUUFBTSxDQUFDUyxPQUFPQyxRQUFRLElBQUlWLFNBQWlCLENBQUM7QUFJNUMsUUFBTVcsWUFBWUEsQ0FBQ0MsTUFBVztBQUM1QixRQUFJQSxFQUFFQyxRQUFRLFNBQVM7QUFDckIsVUFBSSxDQUFDTixlQUFlO0FBQ2xCO0FBQUEsTUFDRjtBQUNBTyxtQkFBYVAsYUFBYTtBQUFBLElBQzVCO0FBQUEsRUFDRjtBQUlBLFdBQVNPLGFBQWFQLGdCQUF1QjtBQUMzQyxRQUFJUSxhQUF1QlIsZUFBY1MsTUFBTSxHQUFHO0FBQ2xELFFBQUlDLFVBQWtCRixXQUFXLENBQUM7QUFDbEMsUUFBSUc7QUFHSixRQUFJQyxTQUFTaEIsZ0JBQWdCaUIsZUFBZUgsU0FBU0YsVUFBVSxFQUM5RE0sS0FBS0YsYUFBVTtBQUNkLFVBQUlBLFFBQU8sQ0FBQyxNQUFNLGlCQUFpQjtBQUNqQyxZQUFJRyxVQUFVakIsTUFBTWtCLFNBQVMsVUFBVSxZQUFZO0FBQ25EbEIsY0FBTW1CLFFBQVFGLE9BQU87QUFBQSxNQUN2QjtBQUNBSixtQkFBYSxJQUFJaEIsUUFBUUssZ0JBQWVZLFFBQU8sQ0FBQyxHQUFHQSxRQUFPLENBQUMsQ0FBQztBQUM1RFQsZUFBU0QsUUFBUSxDQUFDO0FBQ2xCSixZQUFNb0IsV0FBVyxDQUFDLEdBQUdwQixNQUFNcUIsU0FBU1IsVUFBVSxDQUFDO0FBQy9DVix1QkFBaUIsRUFBRTtBQUFBLElBQ3JCLENBQUMsRUFFQW1CLE1BQU1DLFdBQVM7QUFDaEJDLGNBQVFELE1BQU0sbUJBQW1CQSxLQUFLO0FBRXRDbEIsZUFBU0QsUUFBUSxDQUFDO0FBQ2xCUyxtQkFBYSxJQUFJaEIsUUFBUUssZ0JBQWUsSUFBSSxvQkFBa0JxQixLQUFLO0FBQ25FdkIsWUFBTW9CLFdBQVcsQ0FBQyxHQUFHcEIsTUFBTXFCLFNBQVNSLFVBQVUsQ0FBQztBQUMvQ1YsdUJBQWlCLEVBQUU7QUFBQSxJQUNyQixDQUFDO0FBQUEsRUFJRDtBQU9BLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLGNBQWEsV0FBV0csV0FDckM7QUFBQSwyQkFBQyxjQUNDO0FBQUEsNkJBQUMsWUFBTyxjQUFXLFVBQVEsa0dBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsbUJBQ0MsT0FBT0osZUFDUCxVQUFVQyxrQkFDVixXQUFXLG1CQUhiO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHNkI7QUFBQSxTQVIvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBVUE7QUFBQSxJQUNBLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFHO0FBQUEsSUFDSCx1QkFBQyxZQUFPLFNBQVMsTUFBTU0sYUFBYVAsYUFBYSxHQUFFO0FBQUE7QUFBQSxNQUN0Q0U7QUFBQUEsTUFBTTtBQUFBLFNBRG5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLE9BZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWdCQTtBQUVKO0FBQUNILEdBekVlRixXQUFTO0FBQUEwQixLQUFUMUI7QUFBUyxJQUFBMEI7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiQ29udHJvbGxlZElucHV0IiwiQ29tbWFuZCIsIkNvbW1hbmRSZWdpc3RyeSIsIlJFUExJbnB1dCIsInByb3BzIiwiX3MiLCJjb21tYW5kU3RyaW5nIiwic2V0Q29tbWFuZFN0cmluZyIsImNvdW50Iiwic2V0Q291bnQiLCJoYW5kbGVLZXkiLCJlIiwia2V5IiwiaGFuZGxlU3VibWl0IiwiY29tbWFuZEFyciIsInNwbGl0IiwiY29tbWFuZCIsIm5ld0NvbW1hbmQiLCJyZXN1bHQiLCJleGVjdXRlQ29tbWFuZCIsInRoZW4iLCJuZXdNb2RlIiwibW9kZSIsInNldE1vZGUiLCJzZXRIaXN0b3J5IiwiaGlzdG9yeSIsImNhdGNoIiwiZXJyb3IiLCJjb25zb2xlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJSRVBMSW5wdXQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBcIi4uL3N0eWxlcy9tYWluLmNzc1wiO1xuaW1wb3J0IHsgRGlzcGF0Y2gsIFNldFN0YXRlQWN0aW9uLCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgQ29udHJvbGxlZElucHV0IH0gZnJvbSBcIi4vQ29udHJvbGxlZElucHV0XCI7XG5pbXBvcnQgeyBDb21tYW5kIH0gZnJvbSBcIi4uL2Z1bmN0aW9ucy9Db21tYW5kXCI7XG5pbXBvcnQgQ29tbWFuZFJlZ2lzdHJ5IGZyb20gJy4vQ29tbWFuZFJlZ2lzdHJhdGlvbic7XG5cbi8qKlxuICogVGhlc2UgYXJlIHRoZSBwcm9wcyBmb3IgdGhlIFJFUExJbnB1dCBjb21wb25lbnQuXG4gKiAtIGhpc3RvcnkgaXMgYSBsaXN0IG9mIGFsbCBjb21tYW5kcyB0aGF0IGhhdmUgYmVlbiBwdXNoZWQgYnkgdGhlIHVzZXIgaW4gdGhpcyBzZXNzaW9uXG4gKiAtIG1vZGUgaXMgYSBib29sZWFuIHNldCB0byB0cnVlIGlmIGluIGJyaWVmIG1vZGUgKGRlZmF1bHQpLCBhbmQgZmFsc2UgaW4gdmVyYm9zZSBtb2RlXG4gKiAtIHNldEhpc3RvcnkgaXMgYSBmdW5jdGlvbiB0aGF0IGFsbG93cyB0aGUgY2FsbGVyIHRvIHNldCB0aGUgdmFsdWUgb2YgdGhlIGhpc3RvcnkgYXJyYXlcbiAqIC0gc2V0TW9kZSBpcyBhIGZ1bmN0aW9uIHRoYXQgYWxsb3dzIHRoZSBjYWxsZXIgdG8gc2V0IHRoZSB2YWx1ZSBvZiBtb2RlXG4gKi9cbmludGVyZmFjZSBSRVBMSW5wdXRQcm9wcyB7XG4gIGhpc3Rvcnk6IENvbW1hbmRbXTtcbiAgbW9kZTogc3RyaW5nO1xuICBzZXRIaXN0b3J5OiBEaXNwYXRjaDxTZXRTdGF0ZUFjdGlvbjxDb21tYW5kW10+PjtcbiAgc2V0TW9kZTogRGlzcGF0Y2g8U2V0U3RhdGVBY3Rpb248c3RyaW5nPj47XG59XG5cbi8qKlxuICogVGhpcyBjb21wb25lbnQgaXMgY2FsbGVkIGFzIHBhcnQgb2YgdGhlIFJFUEwgY29tcG9uZW50LlxuICogVGhlIFJFUExJbnB1dCBjb21wb25lbnQgdXNlcyBhIHRleHQgaW5wdXQgYmFyIGFuZCBhIHN1Ym1pdCBidXR0b24gdG8gYWxsb3cgdGhlIHVzZXJcbiAqIHRvIGVudGVyIGNvbW1hbmRzIGluIHRoZSBpbnB1dCBib3ggYW5kIHNlbmQgdGhlbSB3aXRoIHRoZSBzdWJtaXQgYnV0dG9uLiBUaGUgUkVQTEhpc3RvcnlcbiAqIGNvbXBvbmVudCBpcyB1cGRhdGVkIGFjY29yZGluZyB0byB0aGUgcmVzdWx0cyBvZiB0aGVzZSBjb21tYW5kcy5cbiAqIFZhbGlkIGNvbW1hbmRzIGluY2x1ZGUgbW9kZSwgbG9hZF9maWxlIDxjc3YtZmlsZS1wYXRoPiwgdmlldywgYW5kIHNlYXJjaCA8Y29sdW1uPiA8dmFsdWU+XG4gKiBAcGFyYW0gcHJvcHMgaXMgdGhlIGludGVyZmFjZSBhYm92ZSBjb250YWluaW5nIHRoZSBhcmd1bWVudHMgdG8gUkVQTElucHV0XG4gKiBAcmV0dXJucyBIVE1MIGRpdiByZXByZXNlbnRpbmcgaW5wdXQgYXJlYSwgd2l0aCBpbnB1dCBib3ggYW5kIHN1Ym1pdCBidXR0b25cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIFJFUExJbnB1dChwcm9wczogUkVQTElucHV0UHJvcHMpIHtcbiAgLy8gVGhlc2UgY29uc3RhbnRzIG1hbmFnZSB0aGUgc3RhdGUgdGhhdCBzdWItY29tcG9uZW50cyBoYXZlIGFjY2VzcyB0b1xuICBjb25zdCBbY29tbWFuZFN0cmluZywgc2V0Q29tbWFuZFN0cmluZ10gPSB1c2VTdGF0ZTxzdHJpbmc+KFwiXCIpO1xuICBjb25zdCBbY291bnQsIHNldENvdW50XSA9IHVzZVN0YXRlPG51bWJlcj4oMCk7XG4gIFxuXG4gIC8vIFRoaXMgZnVuY3Rpb24gZW5hYmxlcyB0aGUgY29tbWFuZCB0byBiZSBzZW50IHdoZW4gdGhlIHJldHVybiBrZXkgaXMgcHJlc3NlZC5cbiAgY29uc3QgaGFuZGxlS2V5ID0gKGU6IGFueSkgPT4ge1xuICAgIGlmIChlLmtleSA9PT0gXCJFbnRlclwiKSB7XG4gICAgICBpZiAoIWNvbW1hbmRTdHJpbmcpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgaGFuZGxlU3VibWl0KGNvbW1hbmRTdHJpbmcpO1xuICAgIH1cbiAgfTtcblxuICAvLyBUaGlzIGZ1bmN0aW9uIGlzIHRyaWdnZXJlZCB3aGVuIHRoZSBidXR0b24gaXMgY2xpY2tlZFxuICAvLyBJdCBkZXBlbmRpbmcgb24gdGhlIGNvbW1hbmQgdGV4dCwgaXQgY3JlYXRlcyBhIENvbW1hbmQgb2JqZWN0XG4gIGZ1bmN0aW9uIGhhbmRsZVN1Ym1pdChjb21tYW5kU3RyaW5nOiBzdHJpbmcpIHtcbiAgICBsZXQgY29tbWFuZEFycjogc3RyaW5nW10gPSBjb21tYW5kU3RyaW5nLnNwbGl0KFwiIFwiKTtcbiAgICBsZXQgY29tbWFuZDogc3RyaW5nID0gY29tbWFuZEFyclswXTtcbiAgICBsZXQgbmV3Q29tbWFuZDogQ29tbWFuZDtcblxuICAgIC8vIGdldCBtYXBwZWQgY29tbWFuZCBmdW5jdGlvbiBhbmQgZXhlY3V0ZSBpdFxuICAgIGxldCByZXN1bHQgPSBDb21tYW5kUmVnaXN0cnkuZXhlY3V0ZUNvbW1hbmQoY29tbWFuZCwgY29tbWFuZEFycilcbiAgICAudGhlbihyZXN1bHQgPT4ge1xuICAgICAgaWYgKHJlc3VsdFswXSA9PT0gXCJNb2RlIHN1Y2Nlc3MhXCIpIHtcbiAgICAgICAgbGV0IG5ld01vZGUgPSBwcm9wcy5tb2RlID09PSBcImJyaWVmXCIgPyBcInZlcmJvc2VcIiA6IFwiYnJpZWZcIjtcbiAgICAgICAgcHJvcHMuc2V0TW9kZShuZXdNb2RlKTtcbiAgICAgIH0gXG4gICAgICBuZXdDb21tYW5kID0gbmV3IENvbW1hbmQoY29tbWFuZFN0cmluZywgcmVzdWx0WzFdLCByZXN1bHRbMF0pO1xuICAgICAgc2V0Q291bnQoY291bnQgKyAxKTtcbiAgICAgIHByb3BzLnNldEhpc3RvcnkoWy4uLnByb3BzLmhpc3RvcnksIG5ld0NvbW1hbmRdKTtcbiAgICAgIHNldENvbW1hbmRTdHJpbmcoXCJcIik7XG4gICAgfSlcbiAgICBcbiAgICAuY2F0Y2goZXJyb3IgPT4ge1xuICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBvY2N1cnJlZDpcIiwgZXJyb3IpO1xuICAgIC8vIEhhbmRsZSB0aGUgZXJyb3IsIGUuZy4sIHVwZGF0ZSB0aGUgVUkgdG8gc2hvdyBhbiBlcnJvciBtZXNzYWdlLlxuICAgIHNldENvdW50KGNvdW50ICsgMSk7XG4gICAgbmV3Q29tbWFuZCA9IG5ldyBDb21tYW5kKGNvbW1hbmRTdHJpbmcsIFtdLCBcIkVycm9yIG9jY3VycmVkOlwiK2Vycm9yKTtcbiAgICBwcm9wcy5zZXRIaXN0b3J5KFsuLi5wcm9wcy5oaXN0b3J5LCBuZXdDb21tYW5kXSk7XG4gICAgc2V0Q29tbWFuZFN0cmluZyhcIlwiKTtcbiAgfSk7XG4gICAgLy8gY29uc29sZS5sb2coJ05ldyBIaXN0b3J5OicsIFsuLi5wcm9wcy5oaXN0b3J5XSk7XG4gICAgXG4gICAgXG4gIH1cblxuICAvKipcbiAgICogVGhpcyByZXR1cm5zIHRoZSBsZWdlbmQsIGlucHV0IGJveCwgYW5kIHN1Ym1pdCBidXR0b24gdGhhdCBhbGxvdyB0aGUgdXNlciB0b1xuICAgKiBzZW5kIGNvbW1hbmRzIGFuZCB1cGRhdGUgdGhlIGFwcCdzIHN0YXRlLCBzbyB0aGF0IGNvbW1hbmRzIGNhbiBiZSBkaXNwbGF5ZWQgYnlcbiAgICogdGhlIFJFUExIaXN0b3J5IGNvbXBvbmVudC5cbiAgICovXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJyZXBsLWlucHV0XCIgb25LZXlEb3duPXtoYW5kbGVLZXl9PlxuICAgICAgPGZpZWxkc2V0PlxuICAgICAgICA8bGVnZW5kIGFyaWEtbGFiZWw9XCJsZWdlbmRcIj5cbiAgICAgICAgICBFbnRlciBhIGNvbW1hbmQ6IG1vZGUsIGxvYWRfZmlsZSAmbHQ7Y3N2LWZpbGUtcGF0aCZndDssIHZpZXcsIG9yXG4gICAgICAgICAgc2VhcmNoICZsdDtjb2x1bW4mZ3Q7ICZsdDt2YWx1ZSZndDtcbiAgICAgICAgPC9sZWdlbmQ+XG4gICAgICAgIDxDb250cm9sbGVkSW5wdXRcbiAgICAgICAgICB2YWx1ZT17Y29tbWFuZFN0cmluZ31cbiAgICAgICAgICBzZXRWYWx1ZT17c2V0Q29tbWFuZFN0cmluZ31cbiAgICAgICAgICBhcmlhTGFiZWw9e1wiQ29tbWFuZCBpbnB1dFwifVxuICAgICAgICAvPlxuICAgICAgPC9maWVsZHNldD5cbiAgICAgIDxiciAvPlxuICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBoYW5kbGVTdWJtaXQoY29tbWFuZFN0cmluZyl9PlxuICAgICAgICBTdWJtaXR0ZWQge2NvdW50fSB0aW1lc1xuICAgICAgPC9idXR0b24+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9pbGFuYS9EZXNrdG9wL0Jyb3duL0NTMzIvcmVwbC1pbmd1eWVuNC10YWluYTEvRnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvUkVQTElucHV0LnRzeCJ9