import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/DataContext.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=d14a5a4b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/DataContext.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=d14a5a4b"; const createContext = __vite__cjsImport3_react["createContext"]; const useContext = __vite__cjsImport3_react["useContext"]; const useState = __vite__cjsImport3_react["useState"];
const DataContext = createContext(void 0);
export const DataProvider = ({
  children
}) => {
  _s();
  const [filepath, setFilepath] = useState("");
  const [broadband, setBroadband] = useState(false);
  return /* @__PURE__ */ jsxDEV(DataContext.Provider, { value: {
    filepath,
    setFilepath,
    broadband,
    setBroadband
  }, children }, void 0, false, {
    fileName: "/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/DataContext.tsx",
    lineNumber: 20,
    columnNumber: 10
  }, this);
};
_s(DataProvider, "cTXs+5tlKzbJ96BPLOF3eOInXww=");
_c = DataProvider;
export const useDataContext = () => {
  _s2();
  const context = useContext(DataContext);
  if (context === void 0) {
    throw new Error("useDataContext must be used within a DataProvider");
  }
  return context;
};
_s2(useDataContext, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c;
$RefreshReg$(_c, "DataProvider");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/DataContext.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0JJOzs7Ozs7Ozs7Ozs7Ozs7OztBQXBCSixTQUFnQkEsZUFBZUMsWUFBWUMsZ0JBQTJCO0FBYXRFLE1BQU1DLGNBQWNILGNBQTJDSSxNQUFTO0FBRWpFLGFBQU1DLGVBQTJDQSxDQUFDO0FBQUEsRUFBRUM7QUFBUyxNQUFNO0FBQUFDLEtBQUE7QUFDeEUsUUFBTSxDQUFDQyxVQUFVQyxXQUFXLElBQUlQLFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUNRLFdBQVdDLFlBQVksSUFBSVQsU0FBUyxLQUFLO0FBRWhELFNBQ0UsdUJBQUMsWUFBWSxVQUFaLEVBQXFCLE9BQU87QUFBQSxJQUFFTTtBQUFBQSxJQUFVQztBQUFBQSxJQUFhQztBQUFBQSxJQUFXQztBQUFBQSxFQUFhLEdBQzNFTCxZQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FFQTtBQUVKO0FBQUVDLEdBVFdGLGNBQXdDO0FBQUFPLEtBQXhDUDtBQVlOLGFBQU1RLGlCQUFpQkEsTUFBTTtBQUFBQyxNQUFBO0FBQ2xDLFFBQU1DLFVBQVVkLFdBQVdFLFdBQVc7QUFDdEMsTUFBSVksWUFBWVgsUUFBVztBQUN6QixVQUFNLElBQUlZLE1BQU0sbURBQW1EO0FBQUEsRUFDckU7QUFDQSxTQUFPRDtBQUNUO0FBQUVELElBTldELGdCQUFjO0FBQUEsSUFBQUQ7QUFBQUssYUFBQUwsSUFBQSIsIm5hbWVzIjpbImNyZWF0ZUNvbnRleHQiLCJ1c2VDb250ZXh0IiwidXNlU3RhdGUiLCJEYXRhQ29udGV4dCIsInVuZGVmaW5lZCIsIkRhdGFQcm92aWRlciIsImNoaWxkcmVuIiwiX3MiLCJmaWxlcGF0aCIsInNldEZpbGVwYXRoIiwiYnJvYWRiYW5kIiwic2V0QnJvYWRiYW5kIiwiX2MiLCJ1c2VEYXRhQ29udGV4dCIsIl9zMiIsImNvbnRleHQiLCJFcnJvciIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkRhdGFDb250ZXh0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgY3JlYXRlQ29udGV4dCwgdXNlQ29udGV4dCwgdXNlU3RhdGUsIFJlYWN0Tm9kZSB9IGZyb20gJ3JlYWN0JztcblxuaW50ZXJmYWNlIERhdGFDb250ZXh0UHJvcHMge1xuICBjaGlsZHJlbjogUmVhY3ROb2RlO1xufVxuXG5pbnRlcmZhY2UgRGF0YUNvbnRleHRUeXBlIHtcbiAgZmlsZXBhdGg6IHN0cmluZztcbiAgc2V0RmlsZXBhdGg6IFJlYWN0LkRpc3BhdGNoPFJlYWN0LlNldFN0YXRlQWN0aW9uPHN0cmluZz4+O1xuICBicm9hZGJhbmQ6IGJvb2xlYW47XG4gIHNldEJyb2FkYmFuZDogUmVhY3QuRGlzcGF0Y2g8UmVhY3QuU2V0U3RhdGVBY3Rpb248Ym9vbGVhbj4+O1xufVxuXG5jb25zdCBEYXRhQ29udGV4dCA9IGNyZWF0ZUNvbnRleHQ8RGF0YUNvbnRleHRUeXBlIHwgdW5kZWZpbmVkPih1bmRlZmluZWQpO1xuXG5leHBvcnQgY29uc3QgRGF0YVByb3ZpZGVyOiBSZWFjdC5GQzxEYXRhQ29udGV4dFByb3BzPiA9ICh7IGNoaWxkcmVuIH0pID0+IHtcbiAgY29uc3QgW2ZpbGVwYXRoLCBzZXRGaWxlcGF0aF0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFticm9hZGJhbmQsIHNldEJyb2FkYmFuZF0gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgcmV0dXJuIChcbiAgICA8RGF0YUNvbnRleHQuUHJvdmlkZXIgdmFsdWU9e3sgZmlsZXBhdGgsIHNldEZpbGVwYXRoLCBicm9hZGJhbmQsIHNldEJyb2FkYmFuZCB9fT5cbiAgICAgIHtjaGlsZHJlbn1cbiAgICA8L0RhdGFDb250ZXh0LlByb3ZpZGVyPlxuICApO1xufTtcblxuXG5leHBvcnQgY29uc3QgdXNlRGF0YUNvbnRleHQgPSAoKSA9PiB7XG4gIGNvbnN0IGNvbnRleHQgPSB1c2VDb250ZXh0KERhdGFDb250ZXh0KTtcbiAgaWYgKGNvbnRleHQgPT09IHVuZGVmaW5lZCkge1xuICAgIHRocm93IG5ldyBFcnJvcigndXNlRGF0YUNvbnRleHQgbXVzdCBiZSB1c2VkIHdpdGhpbiBhIERhdGFQcm92aWRlcicpO1xuICB9XG4gIHJldHVybiBjb250ZXh0O1xufTtcbiJdLCJmaWxlIjoiL1VzZXJzL2lsYW5hL0Rlc2t0b3AvQnJvd24vQ1MzMi9yZXBsLWluZ3V5ZW40LXRhaW5hMS9Gcm9udGVuZC9zcmMvY29tcG9uZW50cy9EYXRhQ29udGV4dC50c3gifQ==