import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/CsvTable.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4cb492d2"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/CsvTable.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
export default function CsvTable(props) {
  const rows = props.data.map((row, index) => {
    return /* @__PURE__ */ jsxDEV("tr", { children: row.map((column, index2) => {
      return /* @__PURE__ */ jsxDEV("td", { "aria-label": props.ariaLabel + "cell" + String(index) + "," + String(index2), children: column }, `cell-${index2}`, false, {
        fileName: "/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/CsvTable.tsx",
        lineNumber: 22,
        columnNumber: 16
      }, this);
    }) }, `row-${index}`, false, {
      fileName: "/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/CsvTable.tsx",
      lineNumber: 20,
      columnNumber: 12
    }, this);
  });
  return /* @__PURE__ */ jsxDEV("table", { "aria-label": props.ariaLabel, children: /* @__PURE__ */ jsxDEV("tbody", { children: rows }, void 0, false, {
    fileName: "/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/CsvTable.tsx",
    lineNumber: 29,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/CsvTable.tsx",
    lineNumber: 28,
    columnNumber: 10
  }, this);
}
_c = CsvTable;
var _c;
$RefreshReg$(_c, "CsvTable");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/CsvTable.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUJZO0FBdkJaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQWlCQSx3QkFBd0JBLFNBQVNDLE9BQXNCO0FBQ3JELFFBQU1DLE9BQU9ELE1BQU1FLEtBQUtDLElBQUksQ0FBQ0MsS0FBZUMsVUFBa0I7QUFDNUQsV0FDRSx1QkFBQyxRQUNFRCxjQUFJRCxJQUFJLENBQUNHLFFBQWdCQyxXQUFtQjtBQUMzQyxhQUNFLHVCQUFDLFFBRUMsY0FDRVAsTUFBTVEsWUFDTixTQUNBQyxPQUFPSixLQUFLLElBQ1osTUFDQUksT0FBT0YsTUFBTSxHQUdkRCxvQkFUSyxRQUFPQyxNQUFPLElBRHRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFXQTtBQUFBLElBRUosQ0FBQyxLQWhCTyxPQUFNRixLQUFNLElBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FpQkE7QUFBQSxFQUVKLENBQUM7QUFFRCxTQUNFLHVCQUFDLFdBQU0sY0FBWUwsTUFBTVEsV0FDdkIsaUNBQUMsV0FBT1Asa0JBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFhLEtBRGY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUVBO0FBRUo7QUFBQ1MsS0E3QnVCWDtBQUFRLElBQUFXO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJDc3ZUYWJsZSIsInByb3BzIiwicm93cyIsImRhdGEiLCJtYXAiLCJyb3ciLCJpbmRleCIsImNvbHVtbiIsImluZGV4MiIsImFyaWFMYWJlbCIsIlN0cmluZyIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQ3N2VGFibGUudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogVGhlc2UgYXJlIHRoZSBwcm9wcyBmb3IgdGhlIENzdlRhYmxlIGNvbXBvbmVudC5cbiAqIC0gZGF0YSBpcyBhIGxpc3Qgb2YgbGlzdCBvZiBzdHJpbmcsIHJlcHJlc2VudGluZyB0aGUgcm93cyBvZiBkYXRhIHJldHVybmVkIGJ5IGEgdmlld1xuICogb3Igc2VhcmNoIGNvbW1hbmQsIG9yIGFuIGVtcHR5IHRhYmxlIGZvciBhIGNvbW1hbmQgdGhhdCBkb2VzIG5vdCByZXR1cm4gZGF0YSAoYSBtb2RlLFxuICogbG9hZF9maWxlLCBvciB1bnJlY29nbml6ZWQgY29tbWFuZClcbiAqL1xuaW50ZXJmYWNlIENzdlRhYmxlUHJvcHMge1xuICBkYXRhOiBzdHJpbmdbXVtdO1xuICBhcmlhTGFiZWw6IHN0cmluZztcbn1cblxuLyoqXG4gKiBUaGlzIGNvbXBvbmVudCBpcyBjYWxsZWQgYXMgcGFydCBvZiB0aGUgUkVQbEhpc3RvcnkgY29tbWFuZCwgZm9yIGV2ZXJ5IHRhYmxlIHRoYXRcbiAqIG5lZWRzIHRvIGJlIGRpc3BsYXllZCBpbiB0aGUgY29tbWFuZCBoaXN0b3J5IGFyZWEuXG4gKiBAcGFyYW0gcHJvcHMgaXMgdGhlIGludGVyZmFjZSBhYm92ZSBjb250YWluaW5nIHRoZSBhcmd1bWVudHMgdG8gQ3N2VGFibGVcbiAqIEByZXR1cm5zIGFuIEhUTUwgdGFibGUgY29udGFpbmluZyB0aGUgQ1NWIGRhdGEgb3V0cHV0IGJ5IGEgY29tbWFuZFxuICovXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBDc3ZUYWJsZShwcm9wczogQ3N2VGFibGVQcm9wcykge1xuICBjb25zdCByb3dzID0gcHJvcHMuZGF0YS5tYXAoKHJvdzogc3RyaW5nW10sIGluZGV4OiBudW1iZXIpID0+IHtcbiAgICByZXR1cm4gKFxuICAgICAgPHRyIGtleT17YHJvdy0ke2luZGV4fWB9PlxuICAgICAgICB7cm93Lm1hcCgoY29sdW1uOiBzdHJpbmcsIGluZGV4MjogbnVtYmVyKSA9PiB7XG4gICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgIDx0ZFxuICAgICAgICAgICAgICBrZXk9e2BjZWxsLSR7aW5kZXgyfWB9XG4gICAgICAgICAgICAgIGFyaWEtbGFiZWw9e1xuICAgICAgICAgICAgICAgIHByb3BzLmFyaWFMYWJlbCArXG4gICAgICAgICAgICAgICAgXCJjZWxsXCIgK1xuICAgICAgICAgICAgICAgIFN0cmluZyhpbmRleCkgK1xuICAgICAgICAgICAgICAgIFwiLFwiICtcbiAgICAgICAgICAgICAgICBTdHJpbmcoaW5kZXgyKVxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIHtjb2x1bW59XG4gICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICk7XG4gICAgICAgIH0pfVxuICAgICAgPC90cj5cbiAgICApO1xuICB9KTtcblxuICByZXR1cm4gKFxuICAgIDx0YWJsZSBhcmlhLWxhYmVsPXtwcm9wcy5hcmlhTGFiZWx9PlxuICAgICAgPHRib2R5Pntyb3dzfTwvdGJvZHk+XG4gICAgPC90YWJsZT5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2lsYW5hL0Rlc2t0b3AvQnJvd24vQ1MzMi9yZXBsLWluZ3V5ZW40LXRhaW5hMS9Gcm9udGVuZC9zcmMvY29tcG9uZW50cy9Dc3ZUYWJsZS50c3gifQ==