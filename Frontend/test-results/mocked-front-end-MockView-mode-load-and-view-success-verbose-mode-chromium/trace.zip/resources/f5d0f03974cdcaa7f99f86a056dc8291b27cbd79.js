import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/REPLHistory.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e8b8e43"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/REPLHistory.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import "/src/styles/main.css";
import CsvTable from "/src/components/CsvTable.tsx";
import __vite__cjsImport5_react from "/node_modules/.vite/deps/react.js?v=7e8b8e43"; const useRef = __vite__cjsImport5_react["useRef"]; const useEffect = __vite__cjsImport5_react["useEffect"]; const useState = __vite__cjsImport5_react["useState"];
export function REPLHistory(props) {
  _s();
  const [scrollPosition, setScrollPosition] = useState(0);
  const messagesEndRef = useRef(null);
  const scrollToBottom = () => {
    messagesEndRef.current.scrollIntoView({
      behavior: "smooth"
    });
  };
  useEffect(() => {
    scrollToBottom();
  }, [props.history]);
  const handleKeyDown = (e) => {
    if (e.key === "ArrowUp") {
      setScrollPosition(scrollPosition - 1);
    } else if (e.key === "ArrowDown") {
      setScrollPosition(scrollPosition + 1);
    }
  };
  const inputRef = useRef(null);
  useEffect(() => {
    const handleKeyPress = (event) => {
      if (event.key === "o" && event.ctrlKey) {
        event.preventDefault();
        if (inputRef.current) {
          inputRef.current.focus();
        }
      }
    };
    window.addEventListener("keydown", handleKeyPress);
    return () => {
      window.removeEventListener("keydown", handleKeyPress);
    };
  }, []);
  return /* @__PURE__ */ jsxDEV("div", { className: "repl-history", tabIndex: -1, onKeyDown: handleKeyDown, ref: inputRef, children: [
    props.history.map((command, index) => props.mode === "brief" ? /* @__PURE__ */ jsxDEV("div", { className: "leftAlign", children: [
      /* @__PURE__ */ jsxDEV("p", { "aria-label": "commandMessage" + String(index), children: command.message }, void 0, false, {
        fileName: "/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/REPLHistory.tsx",
        lineNumber: 70,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(CsvTable, { data: command.data, ariaLabel: "data" + String(index) }, void 0, false, {
        fileName: "/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/REPLHistory.tsx",
        lineNumber: 73,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/REPLHistory.tsx",
        lineNumber: 74,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("hr", {}, void 0, false, {
        fileName: "/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/REPLHistory.tsx",
        lineNumber: 75,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/REPLHistory.tsx",
      lineNumber: 69,
      columnNumber: 71
    }, this) : /* @__PURE__ */ jsxDEV("div", { className: "leftAlign", children: [
      /* @__PURE__ */ jsxDEV("span", { "aria-label": "Command " + String(index) + " is: ", className: "boldText", children: "Command: " }, void 0, false, {
        fileName: "/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/REPLHistory.tsx",
        lineNumber: 77,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("span", { "aria-label": `${command.commandString}`, children: command.commandString }, void 0, false, {
        fileName: "/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/REPLHistory.tsx",
        lineNumber: 78,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/REPLHistory.tsx",
        lineNumber: 81,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("span", { "aria-label": "Output " + String(index) + " is: ", className: "boldText", children: "Output: " }, void 0, false, {
        fileName: "/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/REPLHistory.tsx",
        lineNumber: 82,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("span", { "aria-label": `${command.message}`, children: command.message }, void 0, false, {
        fileName: "/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/REPLHistory.tsx",
        lineNumber: 83,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/REPLHistory.tsx",
        lineNumber: 86,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("span", { "aria-label": "Data " + String(index) + " is: ", className: "boldText", children: "Data:" }, void 0, false, {
        fileName: "/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/REPLHistory.tsx",
        lineNumber: 87,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(CsvTable, { data: command.data, ariaLabel: `${command.data}` }, void 0, false, {
        fileName: "/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/REPLHistory.tsx",
        lineNumber: 88,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/REPLHistory.tsx",
        lineNumber: 89,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("hr", {}, void 0, false, {
        fileName: "/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/REPLHistory.tsx",
        lineNumber: 90,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/REPLHistory.tsx",
      lineNumber: 76,
      columnNumber: 20
    }, this)),
    /* @__PURE__ */ jsxDEV("div", { ref: messagesEndRef }, void 0, false, {
      fileName: "/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/REPLHistory.tsx",
      lineNumber: 92,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/REPLHistory.tsx",
    lineNumber: 68,
    columnNumber: 10
  }, this);
}
_s(REPLHistory, "cUsIAMGO2XaNFt/Vjgf3N62PnPU=");
_c = REPLHistory;
var _c;
$RefreshReg$(_c, "REPLHistory");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/REPLHistory.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUZZOzs7Ozs7Ozs7Ozs7Ozs7OztBQWpGWixPQUFPO0FBQ1AsT0FBT0EsY0FBYztBQUdyQixTQUFTQyxRQUFRQyxXQUFXQyxnQkFBZ0I7QUF3Qm5DLGdCQUFTQyxZQUFZQyxPQUF5QjtBQUFBQyxLQUFBO0FBQ3JELFFBQU0sQ0FBQ0MsZ0JBQWdCQyxpQkFBaUIsSUFBSUwsU0FBaUIsQ0FBQztBQUM5RCxRQUFNTSxpQkFBaUJSLE9BQThCLElBQUk7QUFFekQsUUFBTVMsaUJBQWlCQSxNQUFNO0FBQzNCRCxtQkFBZUUsUUFBU0MsZUFBZTtBQUFBLE1BQUVDLFVBQVU7QUFBQSxJQUFTLENBQUM7QUFBQSxFQUMvRDtBQUVBWCxZQUFVLE1BQU07QUFDZFEsbUJBQWU7QUFBQSxFQUNqQixHQUFHLENBQUNMLE1BQU1TLE9BQU8sQ0FBQztBQUVsQixRQUFNQyxnQkFBZ0JBLENBQUNDLE1BQTJCO0FBQ2hELFFBQUlBLEVBQUVDLFFBQVEsV0FBVztBQUN2QlQsd0JBQWtCRCxpQkFBaUIsQ0FBQztBQUFBLElBQ3RDLFdBQVdTLEVBQUVDLFFBQVEsYUFBYTtBQUNoQ1Qsd0JBQWtCRCxpQkFBaUIsQ0FBQztBQUFBLElBQ3RDO0FBQUEsRUFDRjtBQUVBLFFBQU1XLFdBQVdqQixPQUF5QixJQUFJO0FBRTlDQyxZQUFVLE1BQU07QUFDZCxVQUFNaUIsaUJBQWlCQSxDQUFDQyxVQUF5QjtBQUMvQyxVQUFJQSxNQUFNSCxRQUFRLE9BQU9HLE1BQU1DLFNBQVM7QUFDdENELGNBQU1FLGVBQWU7QUFDckIsWUFBSUosU0FBU1AsU0FBUztBQUNwQk8sbUJBQVNQLFFBQVFZLE1BQU07QUFBQSxRQUN6QjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBRUFDLFdBQU9DLGlCQUFpQixXQUFXTixjQUFjO0FBRWpELFdBQU8sTUFBTTtBQUNYSyxhQUFPRSxvQkFBb0IsV0FBV1AsY0FBYztBQUFBLElBQ3REO0FBQUEsRUFDRixHQUFHLEVBQUU7QUFNTCxTQUNFLHVCQUFDLFNBQ0MsV0FBVSxnQkFDVixVQUFVLElBQ1YsV0FBV0osZUFDWCxLQUFLRyxVQUVKYjtBQUFBQSxVQUFNUyxRQUFRYSxJQUFJLENBQUNDLFNBQVNDLFVBQzFCeEIsTUFBTXlCLFNBQVMsVUFDZCx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLDZCQUFDLE9BQUUsY0FBWSxtQkFBbUJDLE9BQU9GLEtBQUssR0FDM0NELGtCQUFRSSxXQURYO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsWUFBUyxNQUFNSixRQUFRSyxNQUFNLFdBQVcsU0FBU0YsT0FBT0YsS0FBSyxLQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdFO0FBQUEsTUFDaEUsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQUc7QUFBQSxNQUNILHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFHO0FBQUEsU0FOTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT0EsSUFFQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLDZCQUFDLFVBQUssY0FBWSxhQUFZRSxPQUFPRixLQUFLLElBQUcsU0FBUyxXQUFVLFlBQVcseUJBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0Y7QUFBQSxNQUNwRix1QkFBQyxVQUFLLGNBQWEsR0FBRUQsUUFBUU0sYUFBYyxJQUN4Q04sa0JBQVFNLGlCQURYO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQUc7QUFBQSxNQUNILHVCQUFDLFVBQUssY0FBWSxZQUFXSCxPQUFPRixLQUFLLElBQUcsU0FBUyxXQUFVLFlBQVcsd0JBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0Y7QUFBQSxNQUNsRix1QkFBQyxVQUFLLGNBQWEsR0FBRUQsUUFBUUksT0FBUSxJQUNsQ0osa0JBQVFJLFdBRFg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBRztBQUFBLE1BQ0gsdUJBQUMsVUFBSyxjQUFZLFVBQVNELE9BQU9GLEtBQUssSUFBSSxTQUFTLFdBQVUsWUFBVyxxQkFBekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4RTtBQUFBLE1BQzlFLHVCQUFDLFlBQVMsTUFBTUQsUUFBUUssTUFBTSxXQUFZLEdBQUVMLFFBQVFLLElBQUssTUFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyRDtBQUFBLE1BQzNELHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFHO0FBQUEsTUFDSCx1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBRztBQUFBLFNBZEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWVBLENBRUo7QUFBQSxJQUNBLHVCQUFDLFNBQUksS0FBS3hCLGtCQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBeUI7QUFBQSxPQW5DM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW9DQTtBQUVKO0FBQUNILEdBbEZpQkYsYUFBVztBQUFBK0IsS0FBWC9CO0FBQVcsSUFBQStCO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJDc3ZUYWJsZSIsInVzZVJlZiIsInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiUkVQTEhpc3RvcnkiLCJwcm9wcyIsIl9zIiwic2Nyb2xsUG9zaXRpb24iLCJzZXRTY3JvbGxQb3NpdGlvbiIsIm1lc3NhZ2VzRW5kUmVmIiwic2Nyb2xsVG9Cb3R0b20iLCJjdXJyZW50Iiwic2Nyb2xsSW50b1ZpZXciLCJiZWhhdmlvciIsImhpc3RvcnkiLCJoYW5kbGVLZXlEb3duIiwiZSIsImtleSIsImlucHV0UmVmIiwiaGFuZGxlS2V5UHJlc3MiLCJldmVudCIsImN0cmxLZXkiLCJwcmV2ZW50RGVmYXVsdCIsImZvY3VzIiwid2luZG93IiwiYWRkRXZlbnRMaXN0ZW5lciIsInJlbW92ZUV2ZW50TGlzdGVuZXIiLCJtYXAiLCJjb21tYW5kIiwiaW5kZXgiLCJtb2RlIiwiU3RyaW5nIiwibWVzc2FnZSIsImRhdGEiLCJjb21tYW5kU3RyaW5nIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJSRVBMSGlzdG9yeS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFwiLi4vc3R5bGVzL21haW4uY3NzXCI7XG5pbXBvcnQgQ3N2VGFibGUgZnJvbSBcIi4vQ3N2VGFibGVcIjtcbmltcG9ydCB7IENvbW1hbmQgfSBmcm9tIFwiLi4vZnVuY3Rpb25zL0NvbW1hbmRcIjtcblxuaW1wb3J0IHsgdXNlUmVmLCB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5cbi8qKlxuICogVGhlc2UgYXJlIHRoZSBwcm9wcyBmb3IgdGhlIFJFUExIaXN0b3J5IGNvbXBvbmVudC5cbiAqIC0gaGlzdG9yeSBpcyBhIGxpc3Qgb2YgYWxsIGNvbW1hbmRzIHRoYXQgaGF2ZSBiZWVuIHB1c2hlZCBieSB0aGUgdXNlciBpbiB0aGlzIHNlc3Npb25cbiAqIC0gbW9kZSBpcyBhIGJvb2xlYW4gc2V0IHRvIHRydWUgaWYgaW4gYnJpZWYgbW9kZSAoZGVmYXVsdCksIGFuZCBmYWxzZSBpbiB2ZXJib3NlIG1vZGVcbiAqL1xuaW50ZXJmYWNlIFJFUExIaXN0b3J5UHJvcHMge1xuICBoaXN0b3J5OiBDb21tYW5kW107XG4gIG1vZGU6IHN0cmluZztcbn1cblxuLyoqXG4gKiBUaGlzIGNvbXBvbmVudCBpcyBjYWxsZWQgYXMgcGFydCBvZiB0aGUgUkVQTCBjb21wb25lbnQuXG4gKiBUaGUgUkVQTEhpc3RvcnkgY29tcG9uZW50IGRpc3BsYXlzIGVhY2ggb2YgdGhlIG91dHB1dHMgb2YgYWxsIG9mIHRoZSBjb21tYW5kcyBzZW50IGJ5XG4gKiB0aGUgdXNlciBpbiB0aGlzIHNlc3Npb24uIElmIHRoZSBhcHAgaXMgaW4gdmVyYm9zZSBtb2RlLCB0aGUgY29tbWFuZHMgdGhlbXNlbHZlcyBhcmVcbiAqIGFsc28gZGlzcGxheWVkIGluIHRoZSBSRVBMSGlzdG9yeSBhcmVhLlxuICogVGhlIGNvbW1hbmRzIGFyZSBzdGFja2VkIG9uIHRvcCBvZiBvbmUgYW5vdGhlciwgd2l0aCB0aGUgb2xkZXNldCBjb21tYW5kcyBhdCB0aGUgdG9wLiBUaGVcbiAqIGNvbXBvbmVudCBhbHNvIGF1dG8tc2Nyb2xscywgc28gdGhhdCB0aGUgbmV3ZXN0IGNvbW1hbmRzIGFyZSB2aXNpYmxlLlxuICogQHBhcmFtIHByb3BzIGlzIHRoZSBpbnRlcmZhY2UgYWJvdmUgY29udGFpbmluZyB0aGUgYXJndW1lbnRzIHRvIFJFUExIaXN0b3J5XG4gKiBAcmV0dXJucyBIVE1MIGRpdiByZXByZXNlbnRpbmcgY29tbWFuZCBoaXN0b3J5IGxvZ1xuICovXG5cbiAgZXhwb3J0IGZ1bmN0aW9uIFJFUExIaXN0b3J5KHByb3BzOiBSRVBMSGlzdG9yeVByb3BzKSB7XG4gIGNvbnN0IFtzY3JvbGxQb3NpdGlvbiwgc2V0U2Nyb2xsUG9zaXRpb25dID0gdXNlU3RhdGU8bnVtYmVyPigwKTtcbiAgY29uc3QgbWVzc2FnZXNFbmRSZWYgPSB1c2VSZWY8SFRNTERpdkVsZW1lbnQgfCBudWxsPihudWxsKTtcblxuICBjb25zdCBzY3JvbGxUb0JvdHRvbSA9ICgpID0+IHtcbiAgICBtZXNzYWdlc0VuZFJlZi5jdXJyZW50IS5zY3JvbGxJbnRvVmlldyh7IGJlaGF2aW9yOiBcInNtb290aFwiIH0pO1xuICB9O1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgc2Nyb2xsVG9Cb3R0b20oKTtcbiAgfSwgW3Byb3BzLmhpc3RvcnldKTtcblxuICBjb25zdCBoYW5kbGVLZXlEb3duID0gKGU6IFJlYWN0LktleWJvYXJkRXZlbnQpID0+IHtcbiAgICBpZiAoZS5rZXkgPT09IFwiQXJyb3dVcFwiKSB7XG4gICAgICBzZXRTY3JvbGxQb3NpdGlvbihzY3JvbGxQb3NpdGlvbiAtIDEpO1xuICAgIH0gZWxzZSBpZiAoZS5rZXkgPT09IFwiQXJyb3dEb3duXCIpIHtcbiAgICAgIHNldFNjcm9sbFBvc2l0aW9uKHNjcm9sbFBvc2l0aW9uICsgMSk7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGlucHV0UmVmID0gdXNlUmVmPEhUTUxJbnB1dEVsZW1lbnQ+KG51bGwpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgaGFuZGxlS2V5UHJlc3MgPSAoZXZlbnQ6IEtleWJvYXJkRXZlbnQpID0+IHtcbiAgICAgIGlmIChldmVudC5rZXkgPT09ICdvJyAmJiBldmVudC5jdHJsS2V5KSB7XG4gICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgIGlmIChpbnB1dFJlZi5jdXJyZW50KSB7XG4gICAgICAgICAgaW5wdXRSZWYuY3VycmVudC5mb2N1cygpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfTtcblxuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdrZXlkb3duJywgaGFuZGxlS2V5UHJlc3MpO1xuXG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKCdrZXlkb3duJywgaGFuZGxlS2V5UHJlc3MpO1xuICAgIH07XG4gIH0sIFtdKTtcblxuICAvKipcbiAgICogVGhpcyBjb2RlIG1hcHMgZWFjaCBjb21tYW5kIHRvIGFuIEhUTUwgZGl2IHdpdGggaXRzIGNvbW1hbmQgaW5mb3JtYXRpb24gYW5kXG4gICAqIG91dHB1dCBhcyBhIHRhYmxlLCBkZXBlbmRpbmcgb24gd2hhdCBtb2RlIHRoZSBhcHAgaXMgaW4gKGJyaWVmL3ZlcmJvc2UpXG4gICAqL1xuICByZXR1cm4gKFxuICAgIDxkaXZcbiAgICAgIGNsYXNzTmFtZT1cInJlcGwtaGlzdG9yeVwiXG4gICAgICB0YWJJbmRleD17LTF9XG4gICAgICBvbktleURvd249e2hhbmRsZUtleURvd259XG4gICAgICByZWY9e2lucHV0UmVmfVxuICAgID5cbiAgICAgIHtwcm9wcy5oaXN0b3J5Lm1hcCgoY29tbWFuZCwgaW5kZXgpID0+XG4gICAgICAgIChwcm9wcy5tb2RlID09PSBcImJyaWVmXCIpID8gKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGVmdEFsaWduXCI+XG4gICAgICAgICAgICA8cCBhcmlhLWxhYmVsPXtcImNvbW1hbmRNZXNzYWdlXCIgKyBTdHJpbmcoaW5kZXgpfT5cbiAgICAgICAgICAgICAge2NvbW1hbmQubWVzc2FnZX1cbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgIDxDc3ZUYWJsZSBkYXRhPXtjb21tYW5kLmRhdGF9IGFyaWFMYWJlbD17XCJkYXRhXCIgKyBTdHJpbmcoaW5kZXgpfSAvPlxuICAgICAgICAgICAgPGJyIC8+XG4gICAgICAgICAgICA8aHIgLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKSA6IChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxlZnRBbGlnblwiPlxuICAgICAgICAgICAgPHNwYW4gYXJpYS1sYWJlbD17XCJDb21tYW5kIFwiKyBTdHJpbmcoaW5kZXgpICtcIiBpczogXCJ9IGNsYXNzTmFtZT1cImJvbGRUZXh0XCI+Q29tbWFuZDogPC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4gYXJpYS1sYWJlbD17YCR7Y29tbWFuZC5jb21tYW5kU3RyaW5nfWB9PlxuICAgICAgICAgICAgICB7Y29tbWFuZC5jb21tYW5kU3RyaW5nfVxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPGJyIC8+XG4gICAgICAgICAgICA8c3BhbiBhcmlhLWxhYmVsPXtcIk91dHB1dCBcIisgU3RyaW5nKGluZGV4KSArXCIgaXM6IFwifSBjbGFzc05hbWU9XCJib2xkVGV4dFwiPk91dHB1dDogPC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4gYXJpYS1sYWJlbD17YCR7Y29tbWFuZC5tZXNzYWdlfWB9PlxuICAgICAgICAgICAgICB7Y29tbWFuZC5tZXNzYWdlfVxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPGJyIC8+XG4gICAgICAgICAgICA8c3BhbiBhcmlhLWxhYmVsPXtcIkRhdGEgXCIrIFN0cmluZyhpbmRleCkgKyBcIiBpczogXCJ9IGNsYXNzTmFtZT1cImJvbGRUZXh0XCI+RGF0YTo8L3NwYW4+XG4gICAgICAgICAgICA8Q3N2VGFibGUgZGF0YT17Y29tbWFuZC5kYXRhfSBhcmlhTGFiZWw9e2Ake2NvbW1hbmQuZGF0YX1gfSAvPlxuICAgICAgICAgICAgPGJyIC8+XG4gICAgICAgICAgICA8aHIgLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKVxuICAgICAgKX1cbiAgICAgIDxkaXYgcmVmPXttZXNzYWdlc0VuZFJlZn0gLz5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2lsYW5hL0Rlc2t0b3AvQnJvd24vQ1MzMi9yZXBsLWluZ3V5ZW40LXRhaW5hMS9Gcm9udGVuZC9zcmMvY29tcG9uZW50cy9SRVBMSGlzdG9yeS50c3gifQ==