import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/App.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4c1ef5d8"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/App.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import "/src/styles/App.css";
import REPL from "/src/components/REPL.tsx";
import CommandRegistry from "/src/components/CommandRegistration.tsx";
import { mode } from "/src/functions/Mode.ts";
import { load } from "/src/functions/Load.ts?t=1698289051924";
import { view } from "/src/functions/View.ts";
import { search } from "/src/functions/Search.ts";
function App() {
  CommandRegistry.registerCommand("mode", mode);
  CommandRegistry.registerCommand("load_file", load);
  CommandRegistry.registerCommand("view", view);
  CommandRegistry.registerCommand("search", search);
  return /* @__PURE__ */ jsxDEV("div", { className: "App", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "App-header", children: /* @__PURE__ */ jsxDEV("h1", { "aria-label": "title", children: "Mock" }, void 0, false, {
      fileName: "/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/App.tsx",
      lineNumber: 21,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/App.tsx",
      lineNumber: 20,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(REPL, {}, void 0, false, {
      fileName: "/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/App.tsx",
      lineNumber: 23,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/App.tsx",
    lineNumber: 19,
    columnNumber: 10
  }, this);
}
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/ilana/Desktop/Brown/CS32/repl-inguyen4-taina1/Frontend/src/components/App.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUJRO0FBdkJSLE9BQU8sb0JBQW1CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQzFCLE9BQU9BLFVBQVU7QUFDakIsT0FBT0MscUJBQXFCO0FBQzVCLFNBQVNDLFlBQVk7QUFDckIsU0FBU0MsWUFBWTtBQUNyQixTQUFTQyxZQUFZO0FBQ3JCLFNBQVNDLGNBQWM7QUFRdkIsU0FBU0MsTUFBTTtBQUNYTCxrQkFBZ0JNLGdCQUFnQixRQUFRTCxJQUFJO0FBQzVDRCxrQkFBZ0JNLGdCQUFnQixhQUFhSixJQUFJO0FBQ2pERixrQkFBZ0JNLGdCQUFnQixRQUFRSCxJQUFJO0FBQzVDSCxrQkFBZ0JNLGdCQUFnQixVQUFVRixNQUFNO0FBRWxELFNBQ0UsdUJBQUMsU0FBSSxXQUFVLE9BQ2I7QUFBQSwyQkFBQyxTQUFJLFdBQVUsY0FDYixpQ0FBQyxRQUFHLGNBQVcsU0FBUSxvQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEyQixLQUQ3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUNBLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFLO0FBQUEsT0FKUDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBS0E7QUFFSjtBQUFDRyxLQWRRRjtBQWdCVCxlQUFlQTtBQUFJLElBQUFFO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJSRVBMIiwiQ29tbWFuZFJlZ2lzdHJ5IiwibW9kZSIsImxvYWQiLCJ2aWV3Iiwic2VhcmNoIiwiQXBwIiwicmVnaXN0ZXJDb21tYW5kIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJBcHAudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBcIi4uL3N0eWxlcy9BcHAuY3NzXCI7XG5pbXBvcnQgUkVQTCBmcm9tIFwiLi9SRVBMXCI7XG5pbXBvcnQgQ29tbWFuZFJlZ2lzdHJ5IGZyb20gJy4vQ29tbWFuZFJlZ2lzdHJhdGlvbic7XG5pbXBvcnQgeyBtb2RlIH0gZnJvbSBcIi4uL2Z1bmN0aW9ucy9Nb2RlXCI7XG5pbXBvcnQgeyBsb2FkIH0gZnJvbSBcIi4uL2Z1bmN0aW9ucy9Mb2FkXCI7XG5pbXBvcnQgeyB2aWV3IH0gZnJvbSBcIi4uL2Z1bmN0aW9ucy9WaWV3XCI7XG5pbXBvcnQgeyBzZWFyY2ggfSBmcm9tIFwiLi4vZnVuY3Rpb25zL1NlYXJjaFwiO1xuXG5cbi8qKlxuICogVGhpcyBpcyB0aGUgaGlnaGVzdCBsZXZlbCBjb21wb25lbnQhXG4gKiBJdCBjb250YWlucyBvdXIgUkVQTCBjb21wb25lbnQsIHdoaWNoIGlzIHdoZXJlIGV2ZXJ5dGhpbmcgaXMgZGlzcGxheWVkOiBcbiAqIHRoZSBSRVBMSGlzdG9yeSBhbmQgdGhlIFJFUExJbnB1dCBhcmVhcyFcbiAqL1xuZnVuY3Rpb24gQXBwKCkge1xuICAgIENvbW1hbmRSZWdpc3RyeS5yZWdpc3RlckNvbW1hbmQoJ21vZGUnLCBtb2RlKTtcbiAgICBDb21tYW5kUmVnaXN0cnkucmVnaXN0ZXJDb21tYW5kKCdsb2FkX2ZpbGUnLCBsb2FkKTtcbiAgICBDb21tYW5kUmVnaXN0cnkucmVnaXN0ZXJDb21tYW5kKCd2aWV3Jywgdmlldyk7XG4gICAgQ29tbWFuZFJlZ2lzdHJ5LnJlZ2lzdGVyQ29tbWFuZCgnc2VhcmNoJywgc2VhcmNoKTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiQXBwXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIkFwcC1oZWFkZXJcIj5cbiAgICAgICAgPGgxIGFyaWEtbGFiZWw9XCJ0aXRsZVwiPk1vY2s8L2gxPlxuICAgICAgPC9kaXY+XG4gICAgICA8UkVQTCAvPlxuICAgIDwvZGl2PlxuICApO1xufVxuXG5leHBvcnQgZGVmYXVsdCBBcHA7XG4iXSwiZmlsZSI6Ii9Vc2Vycy9pbGFuYS9EZXNrdG9wL0Jyb3duL0NTMzIvcmVwbC1pbmd1eWVuNC10YWluYTEvRnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvQXBwLnRzeCJ9