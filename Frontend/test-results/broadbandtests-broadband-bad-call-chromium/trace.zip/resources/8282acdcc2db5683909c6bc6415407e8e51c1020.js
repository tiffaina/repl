import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/REPLInput.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=77b65088"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/tiffneyaina/CS32/mock-jstifel1-taina1/mock/src/components/REPLInput.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import "/src/styles/main.css";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=77b65088"; const useState = __vite__cjsImport4_react["useState"];
import { ControlledInput } from "/src/components/ControlledInput.tsx";
import { mockedDataMap } from "/src/mocked_data/mockedJson.ts";
import { mockedSearchResults } from "/src/mocked_data/mockedSearchJson.ts";
export function REPLInput(props) {
  _s();
  const [commandString, setCommandString] = useState("");
  const [count, setCount] = useState(0);
  const [csvloaded, setcsvload] = useState(false);
  const [csvdata, setCsvData] = useState([[]]);
  const [header, setHeader] = useState([]);
  const [isHeader, setIsHeader] = useState(false);
  const [filePathSearch, setFilePath] = useState("");
  function handleSubmit(commandString2) {
    setCount(count + 1);
    const Output = handleOutput(commandString2);
    const newHistoryEntry = {
      command: commandString2,
      result: Output
    };
    props.setHistory([...props.history, newHistoryEntry]);
    setCommandString("");
    function handleOutput(commandString3) {
      const [command, ...args] = commandString3.split(" ");
      if (command === "mode") {
        return handleModeCommand(args);
      } else if (command === "load_file") {
        return handleLoadCSV(args);
      } else if (command === "view") {
        return handleViewCommand(args);
      } else if (command === "search") {
        return handleSearchCommand(args);
      } else {
        return [["Invalid command: " + command]];
      }
    }
    function handleModeCommand(args) {
      if (args.length !== 0) {
        return [["Error - Mode Should Not Include Other Args"]];
      } else {
        let newMode;
        props.setOutputMode((prevMode) => {
          newMode = prevMode === "brief" ? "verbose" : "brief";
          return newMode;
        });
        return [[`Output mode switched to ${newMode}`]];
      }
    }
    function handleLoadCSV(args) {
      var isHeaderCopy = false;
      const [filePath, ...flags] = args;
      if (flags.length !== 0) {
        const [header2, ...rest] = flags;
        if (header2 === "header" && rest.length === 0) {
          setIsHeader(true);
          isHeaderCopy = true;
        } else {
          return [["Error - Extra Args after loadCSV that is not 'header'"]];
        }
      }
      if (filePath in mockedDataMap) {
        if (isHeaderCopy) {
          const [header2, ...rest] = mockedDataMap[filePath];
          setHeader(header2);
          setCsvData(rest);
        } else {
          setCsvData(mockedDataMap[filePath]);
        }
        setFilePath(filePath);
        setcsvload(true);
        return [["CSV Successfully Loaded"]];
      } else {
        setIsHeader(false);
        return [[`Error - ${filePath} not present`]];
      }
    }
    function handleViewCommand(args) {
      if (!csvloaded) {
        return [["Error - No CSV Loaded"]];
      }
      if (args.length !== 0) {
        return [["Error - View Should Not Include Other Args"]];
      } else {
        return [header, ...csvdata];
      }
    }
    function handleSearchCommand(args) {
      if (!csvloaded) {
        return [["Error - No CSV Loaded"]];
      }
      if (args.length < 2) {
        return [["Error - Too Few Arguments, Add a <column> and <value> to search"]];
      } else {
        const [column, value, ...rest] = args;
        if (rest.length !== 0) {
          return [["Error - Do Not Enter Args Other Than Column and Value"]];
        } else {
          return mockedSearchResults[filePathSearch + "-results"];
        }
      }
    }
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "repl-input", children: [
    /* @__PURE__ */ jsxDEV("fieldset", { children: [
      /* @__PURE__ */ jsxDEV("legend", { children: "Enter a command:" }, void 0, false, {
        fileName: "/Users/tiffneyaina/CS32/mock-jstifel1-taina1/mock/src/components/REPLInput.tsx",
        lineNumber: 138,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(ControlledInput, { value: commandString, setValue: setCommandString, ariaLabel: "Command input" }, void 0, false, {
        fileName: "/Users/tiffneyaina/CS32/mock-jstifel1-taina1/mock/src/components/REPLInput.tsx",
        lineNumber: 139,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/tiffneyaina/CS32/mock-jstifel1-taina1/mock/src/components/REPLInput.tsx",
      lineNumber: 137,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("button", { onClick: () => handleSubmit(commandString), children: [
      "Submitted ",
      count,
      " times"
    ] }, void 0, true, {
      fileName: "/Users/tiffneyaina/CS32/mock-jstifel1-taina1/mock/src/components/REPLInput.tsx",
      lineNumber: 141,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/tiffneyaina/CS32/mock-jstifel1-taina1/mock/src/components/REPLInput.tsx",
    lineNumber: 136,
    columnNumber: 10
  }, this);
}
_s(REPLInput, "Dj2oWGNpereff49Wgl2E30/XCqk=");
_c = REPLInput;
var _c;
$RefreshReg$(_c, "REPLInput");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/tiffneyaina/CS32/mock-jstifel1-taina1/mock/src/components/REPLInput.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0pROzs7Ozs7Ozs7Ozs7Ozs7OztBQWhKUixPQUFPO0FBQ1AsU0FBbUNBLGdCQUFnQjtBQUNuRCxTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0MscUJBQXFCO0FBQzlCLFNBQVNDLDJCQUEyQjtBQWlCN0IsZ0JBQVNDLFVBQVVDLE9BQXVCO0FBQUFDLEtBQUE7QUFFL0MsUUFBTSxDQUFDQyxlQUFlQyxnQkFBZ0IsSUFBSVIsU0FBaUIsRUFBRTtBQUU3RCxRQUFNLENBQUNTLE9BQU9DLFFBQVEsSUFBSVYsU0FBaUIsQ0FBQztBQUU1QyxRQUFNLENBQUNXLFdBQVdDLFVBQVUsSUFBSVosU0FBa0IsS0FBSztBQUN2RCxRQUFNLENBQUNhLFNBQVNDLFVBQVUsSUFBSWQsU0FBcUIsQ0FBQyxFQUFFLENBQUM7QUFDdkQsUUFBTSxDQUFDZSxRQUFRQyxTQUFTLElBQUloQixTQUFtQixFQUFFO0FBQ2pELFFBQU0sQ0FBQ2lCLFVBQVVDLFdBQVcsSUFBSWxCLFNBQWtCLEtBQUs7QUFDdkQsUUFBTSxDQUFDbUIsZ0JBQWdCQyxXQUFXLElBQUlwQixTQUFpQixFQUFFO0FBR3pELFdBQVNxQixhQUFhZCxnQkFBdUI7QUFDM0NHLGFBQVNELFFBQVEsQ0FBQztBQUNsQixVQUFNYSxTQUFxQkMsYUFBYWhCLGNBQWE7QUFDckQsVUFBTWlCLGtCQUFpQztBQUFBLE1BQ3JDQyxTQUFTbEI7QUFBQUEsTUFDVG1CLFFBQVFKO0FBQUFBLElBQ1Y7QUFDQWpCLFVBQU1zQixXQUFXLENBQUMsR0FBR3RCLE1BQU11QixTQUFTSixlQUFlLENBQUM7QUFDcERoQixxQkFBaUIsRUFBRTtBQUduQixhQUFTZSxhQUFhaEIsZ0JBQXVCO0FBQzNDLFlBQU0sQ0FBQ2tCLFNBQVMsR0FBR0ksSUFBSSxJQUFJdEIsZUFBY3VCLE1BQU0sR0FBRztBQUNsRCxVQUFJTCxZQUFZLFFBQVE7QUFDdEIsZUFBT00sa0JBQWtCRixJQUFJO0FBQUEsTUFDL0IsV0FBV0osWUFBWSxhQUFhO0FBQ2xDLGVBQU9PLGNBQWNILElBQUk7QUFBQSxNQUMzQixXQUFXSixZQUFZLFFBQVE7QUFDN0IsZUFBT1Esa0JBQWtCSixJQUFJO0FBQUEsTUFDL0IsV0FBV0osWUFBWSxVQUFVO0FBQy9CLGVBQU9TLG9CQUFvQkwsSUFBSTtBQUFBLE1BQ2pDLE9BQU87QUFDTCxlQUFPLENBQUMsQ0FBQyxzQkFBc0JKLE9BQU8sQ0FBQztBQUFBLE1BQ3pDO0FBQUEsSUFDRjtBQUdBLGFBQVNNLGtCQUFrQkYsTUFBZ0I7QUFDekMsVUFBSUEsS0FBS00sV0FBVyxHQUFHO0FBQ3JCLGVBQU8sQ0FBQyxDQUFDLDRDQUE0QyxDQUFDO0FBQUEsTUFDeEQsT0FBTztBQUNMLFlBQUlDO0FBQ0ovQixjQUFNZ0MsY0FBZUMsY0FBYTtBQUNoQ0Ysb0JBQVVFLGFBQWEsVUFBVSxZQUFZO0FBQzdDLGlCQUFPRjtBQUFBQSxRQUNULENBQUM7QUFDRCxlQUFPLENBQUMsQ0FBRSwyQkFBMEJBLE9BQVEsRUFBQyxDQUFDO0FBQUEsTUFDaEQ7QUFBQSxJQUNGO0FBSUEsYUFBU0osY0FBY0gsTUFBNEI7QUFDakQsVUFBSVUsZUFBd0I7QUFDNUIsWUFBTSxDQUFDQyxVQUFVLEdBQUdDLEtBQUssSUFBSVo7QUFDN0IsVUFBSVksTUFBTU4sV0FBVyxHQUFHO0FBQ3RCLGNBQU0sQ0FBQ3BCLFNBQVEsR0FBRzJCLElBQUksSUFBSUQ7QUFDMUIsWUFBSTFCLFlBQVcsWUFBWTJCLEtBQUtQLFdBQVcsR0FBRztBQUM1Q2pCLHNCQUFZLElBQUk7QUFDaEJxQix5QkFBZTtBQUFBLFFBQ2pCLE9BQU87QUFDTCxpQkFBTyxDQUNMLENBQ0UsdURBQXVELENBQ3hEO0FBQUEsUUFFTDtBQUFBLE1BQ0Y7QUFDQSxVQUFJQyxZQUFZdEMsZUFBZTtBQUM3QixZQUFJcUMsY0FBYztBQUNoQixnQkFBTSxDQUFDeEIsU0FBUSxHQUFHMkIsSUFBSSxJQUFJeEMsY0FBY3NDLFFBQVE7QUFDaER4QixvQkFBVUQsT0FBTTtBQUNoQkQscUJBQVc0QixJQUFJO0FBQUEsUUFDakIsT0FBTztBQUNMNUIscUJBQVdaLGNBQWNzQyxRQUFRLENBQUM7QUFBQSxRQUNwQztBQUNBcEIsb0JBQVlvQixRQUFRO0FBQ3BCNUIsbUJBQVcsSUFBSTtBQUNmLGVBQU8sQ0FBQyxDQUFDLHlCQUF5QixDQUFDO0FBQUEsTUFDckMsT0FBTztBQUNMTSxvQkFBWSxLQUFLO0FBQ2pCLGVBQU8sQ0FBQyxDQUFFLFdBQVVzQixRQUFTLGNBQWEsQ0FBQztBQUFBLE1BQzdDO0FBQUEsSUFDRjtBQUdBLGFBQVNQLGtCQUFrQkosTUFBZ0I7QUFDekMsVUFBSSxDQUFDbEIsV0FBVztBQUNkLGVBQU8sQ0FBQyxDQUFDLHVCQUF1QixDQUFDO0FBQUEsTUFDbkM7QUFDQSxVQUFJa0IsS0FBS00sV0FBVyxHQUFHO0FBQ3JCLGVBQU8sQ0FBQyxDQUFDLDRDQUE0QyxDQUFDO0FBQUEsTUFDeEQsT0FBTztBQUNMLGVBQU8sQ0FBQ3BCLFFBQVEsR0FBR0YsT0FBTztBQUFBLE1BQzVCO0FBQUEsSUFDRjtBQUdBLGFBQVNxQixvQkFBb0JMLE1BQWdCO0FBQzNDLFVBQUksQ0FBQ2xCLFdBQVc7QUFDZCxlQUFPLENBQUMsQ0FBQyx1QkFBdUIsQ0FBQztBQUFBLE1BQ25DO0FBQ0EsVUFBSWtCLEtBQUtNLFNBQVMsR0FBRztBQUNuQixlQUFPLENBQ0wsQ0FBQyxpRUFBaUUsQ0FBQztBQUFBLE1BRXZFLE9BQU87QUFDTCxjQUFNLENBQUNRLFFBQVFDLE9BQU8sR0FBR0YsSUFBSSxJQUFJYjtBQUNqQyxZQUFJYSxLQUFLUCxXQUFXLEdBQUc7QUFDckIsaUJBQU8sQ0FBQyxDQUFDLHVEQUF1RCxDQUFDO0FBQUEsUUFDbkUsT0FBTztBQUNMLGlCQUFPaEMsb0JBQW9CZ0IsaUJBQWlCLFVBQVU7QUFBQSxRQUN4RDtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUVBLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSwyQkFBQyxjQUNDO0FBQUEsNkJBQUMsWUFBTyxnQ0FBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdCO0FBQUEsTUFDeEIsdUJBQUMsbUJBQ0MsT0FBT1osZUFDUCxVQUFVQyxrQkFDVixXQUFXLG1CQUhiO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHNkI7QUFBQSxTQUwvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT0E7QUFBQSxJQUNBLHVCQUFDLFlBQU8sU0FBUyxNQUFNYSxhQUFhZCxhQUFhLEdBQUU7QUFBQTtBQUFBLE1BQ3RDRTtBQUFBQSxNQUFNO0FBQUEsU0FEbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsT0FYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBWUE7QUFFSjtBQUFDSCxHQXZJZUYsV0FBUztBQUFBeUMsS0FBVHpDO0FBQVMsSUFBQXlDO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsIkNvbnRyb2xsZWRJbnB1dCIsIm1vY2tlZERhdGFNYXAiLCJtb2NrZWRTZWFyY2hSZXN1bHRzIiwiUkVQTElucHV0IiwicHJvcHMiLCJfcyIsImNvbW1hbmRTdHJpbmciLCJzZXRDb21tYW5kU3RyaW5nIiwiY291bnQiLCJzZXRDb3VudCIsImNzdmxvYWRlZCIsInNldGNzdmxvYWQiLCJjc3ZkYXRhIiwic2V0Q3N2RGF0YSIsImhlYWRlciIsInNldEhlYWRlciIsImlzSGVhZGVyIiwic2V0SXNIZWFkZXIiLCJmaWxlUGF0aFNlYXJjaCIsInNldEZpbGVQYXRoIiwiaGFuZGxlU3VibWl0IiwiT3V0cHV0IiwiaGFuZGxlT3V0cHV0IiwibmV3SGlzdG9yeUVudHJ5IiwiY29tbWFuZCIsInJlc3VsdCIsInNldEhpc3RvcnkiLCJoaXN0b3J5IiwiYXJncyIsInNwbGl0IiwiaGFuZGxlTW9kZUNvbW1hbmQiLCJoYW5kbGVMb2FkQ1NWIiwiaGFuZGxlVmlld0NvbW1hbmQiLCJoYW5kbGVTZWFyY2hDb21tYW5kIiwibGVuZ3RoIiwibmV3TW9kZSIsInNldE91dHB1dE1vZGUiLCJwcmV2TW9kZSIsImlzSGVhZGVyQ29weSIsImZpbGVQYXRoIiwiZmxhZ3MiLCJyZXN0IiwiY29sdW1uIiwidmFsdWUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlJFUExJbnB1dC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFwiLi4vc3R5bGVzL21haW4uY3NzXCI7XG5pbXBvcnQgeyBEaXNwYXRjaCwgU2V0U3RhdGVBY3Rpb24sIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBDb250cm9sbGVkSW5wdXQgfSBmcm9tIFwiLi9Db250cm9sbGVkSW5wdXRcIjtcbmltcG9ydCB7IG1vY2tlZERhdGFNYXAgfSBmcm9tIFwiLi4vbW9ja2VkX2RhdGEvbW9ja2VkSnNvblwiO1xuaW1wb3J0IHsgbW9ja2VkU2VhcmNoUmVzdWx0cyB9IGZyb20gXCIuLi9tb2NrZWRfZGF0YS9tb2NrZWRTZWFyY2hKc29uXCI7XG5cbi8vIERlZmluZSB0aGUgc2hhcGUgb2YgaGlzdG9yeSBlbnRyaWVzXG5pbnRlcmZhY2UgSGlzdG9yeU9iamVjdCB7XG4gIGNvbW1hbmQ6IHN0cmluZztcbiAgcmVzdWx0OiBzdHJpbmdbXVtdO1xufVxuXG4vLyBEZWZpbmUgdGhlIHByb3BlcnRpZXMgZm9yIHRoZSBSRVBMSW5wdXQgY29tcG9uZW50XG5pbnRlcmZhY2UgUkVQTElucHV0UHJvcHMge1xuICBoaXN0b3J5OiBIaXN0b3J5T2JqZWN0W107XG4gIHNldEhpc3Rvcnk6IERpc3BhdGNoPFNldFN0YXRlQWN0aW9uPEhpc3RvcnlPYmplY3RbXT4+O1xuICBvdXRwdXRNb2RlOiBzdHJpbmc7XG4gIHNldE91dHB1dE1vZGU6IERpc3BhdGNoPFNldFN0YXRlQWN0aW9uPHN0cmluZz4+O1xufVxuXG4vLyBUaGUgUkVQTElucHV0IGNvbXBvbmVudCBmb3IgaGFuZGxpbmcgdXNlciBpbnB1dCBhbmQgY29tbWFuZCBleGVjdXRpb25cbmV4cG9ydCBmdW5jdGlvbiBSRVBMSW5wdXQocHJvcHM6IFJFUExJbnB1dFByb3BzKSB7XG4gIC8vIE1hbmFnZSB0aGUgY29udGVudHMgb2YgdGhlIGlucHV0IGJveFxuICBjb25zdCBbY29tbWFuZFN0cmluZywgc2V0Q29tbWFuZFN0cmluZ10gPSB1c2VTdGF0ZTxzdHJpbmc+KFwiXCIpO1xuICAvLyBNYW5hZ2UgdGhlIGN1cnJlbnQgY291bnQgb2YgdGltZXMgdGhlIGJ1dHRvbiBpcyBjbGlja2VkXG4gIGNvbnN0IFtjb3VudCwgc2V0Q291bnRdID0gdXNlU3RhdGU8bnVtYmVyPigwKTtcbiAgLy8gTWFuYWdlIHRoZSBzdGF0ZSBvZiBDU1YgZGF0YSBsb2FkaW5nXG4gIGNvbnN0IFtjc3Zsb2FkZWQsIHNldGNzdmxvYWRdID0gdXNlU3RhdGU8Ym9vbGVhbj4oZmFsc2UpO1xuICBjb25zdCBbY3N2ZGF0YSwgc2V0Q3N2RGF0YV0gPSB1c2VTdGF0ZTxzdHJpbmdbXVtdPihbW11dKTtcbiAgY29uc3QgW2hlYWRlciwgc2V0SGVhZGVyXSA9IHVzZVN0YXRlPHN0cmluZ1tdPihbXSk7XG4gIGNvbnN0IFtpc0hlYWRlciwgc2V0SXNIZWFkZXJdID0gdXNlU3RhdGU8Ym9vbGVhbj4oZmFsc2UpO1xuICBjb25zdCBbZmlsZVBhdGhTZWFyY2gsIHNldEZpbGVQYXRoXSA9IHVzZVN0YXRlPHN0cmluZz4oXCJcIik7XG5cbiAgLy8gSGFuZGxlIHRoZSBzdWJtaXNzaW9uIG9mIGEgY29tbWFuZCBzdHJpbmdcbiAgZnVuY3Rpb24gaGFuZGxlU3VibWl0KGNvbW1hbmRTdHJpbmc6IHN0cmluZykge1xuICAgIHNldENvdW50KGNvdW50ICsgMSk7XG4gICAgY29uc3QgT3V0cHV0OiBzdHJpbmdbXVtdID0gaGFuZGxlT3V0cHV0KGNvbW1hbmRTdHJpbmcpO1xuICAgIGNvbnN0IG5ld0hpc3RvcnlFbnRyeTogSGlzdG9yeU9iamVjdCA9IHtcbiAgICAgIGNvbW1hbmQ6IGNvbW1hbmRTdHJpbmcsXG4gICAgICByZXN1bHQ6IE91dHB1dCxcbiAgICB9O1xuICAgIHByb3BzLnNldEhpc3RvcnkoWy4uLnByb3BzLmhpc3RvcnksIG5ld0hpc3RvcnlFbnRyeV0pO1xuICAgIHNldENvbW1hbmRTdHJpbmcoXCJcIik7XG5cbiAgICAvLyBIYW5kbGUgdGhlIG91dHB1dCBmb3IgdGhlIGdpdmVuIGNvbW1hbmRcbiAgICBmdW5jdGlvbiBoYW5kbGVPdXRwdXQoY29tbWFuZFN0cmluZzogc3RyaW5nKSB7XG4gICAgICBjb25zdCBbY29tbWFuZCwgLi4uYXJnc10gPSBjb21tYW5kU3RyaW5nLnNwbGl0KFwiIFwiKTtcbiAgICAgIGlmIChjb21tYW5kID09PSBcIm1vZGVcIikge1xuICAgICAgICByZXR1cm4gaGFuZGxlTW9kZUNvbW1hbmQoYXJncyk7XG4gICAgICB9IGVsc2UgaWYgKGNvbW1hbmQgPT09IFwibG9hZF9maWxlXCIpIHtcbiAgICAgICAgcmV0dXJuIGhhbmRsZUxvYWRDU1YoYXJncyk7XG4gICAgICB9IGVsc2UgaWYgKGNvbW1hbmQgPT09IFwidmlld1wiKSB7XG4gICAgICAgIHJldHVybiBoYW5kbGVWaWV3Q29tbWFuZChhcmdzKTtcbiAgICAgIH0gZWxzZSBpZiAoY29tbWFuZCA9PT0gXCJzZWFyY2hcIikge1xuICAgICAgICByZXR1cm4gaGFuZGxlU2VhcmNoQ29tbWFuZChhcmdzKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJldHVybiBbW1wiSW52YWxpZCBjb21tYW5kOiBcIiArIGNvbW1hbmRdXTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBIYW5kbGUgdGhlICdtb2RlJyBjb21tYW5kIGFuZCBzd2l0Y2ggdGhlIG91dHB1dCBtb2RlXG4gICAgZnVuY3Rpb24gaGFuZGxlTW9kZUNvbW1hbmQoYXJnczogc3RyaW5nW10pIHtcbiAgICAgIGlmIChhcmdzLmxlbmd0aCAhPT0gMCkge1xuICAgICAgICByZXR1cm4gW1tcIkVycm9yIC0gTW9kZSBTaG91bGQgTm90IEluY2x1ZGUgT3RoZXIgQXJnc1wiXV07XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBsZXQgbmV3TW9kZTtcbiAgICAgICAgcHJvcHMuc2V0T3V0cHV0TW9kZSgocHJldk1vZGUpID0+IHtcbiAgICAgICAgICBuZXdNb2RlID0gcHJldk1vZGUgPT09IFwiYnJpZWZcIiA/IFwidmVyYm9zZVwiIDogXCJicmllZlwiO1xuICAgICAgICAgIHJldHVybiBuZXdNb2RlO1xuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIFtbYE91dHB1dCBtb2RlIHN3aXRjaGVkIHRvICR7bmV3TW9kZX1gXV07XG4gICAgICB9XG4gICAgfVxuIFxuXG4gICAgLy8gSGFuZGxlIHRoZSAnbG9hZF9jc3YnIGNvbW1hbmQgYW5kIGxvYWQgYSBDU1YgZmlsZVxuICAgIGZ1bmN0aW9uIGhhbmRsZUxvYWRDU1YoYXJnczogc3RyaW5nW10pOiBzdHJpbmdbXVtdIHtcbiAgICAgIHZhciBpc0hlYWRlckNvcHk6IGJvb2xlYW4gPSBmYWxzZTtcbiAgICAgIGNvbnN0IFtmaWxlUGF0aCwgLi4uZmxhZ3NdID0gYXJncztcbiAgICAgIGlmIChmbGFncy5sZW5ndGggIT09IDApIHtcbiAgICAgICAgY29uc3QgW2hlYWRlciwgLi4ucmVzdF0gPSBmbGFncztcbiAgICAgICAgaWYgKGhlYWRlciA9PT0gXCJoZWFkZXJcIiAmJiByZXN0Lmxlbmd0aCA9PT0gMCkge1xuICAgICAgICAgIHNldElzSGVhZGVyKHRydWUpO1xuICAgICAgICAgIGlzSGVhZGVyQ29weSA9IHRydWU7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgcmV0dXJuIFtcbiAgICAgICAgICAgIFtcbiAgICAgICAgICAgICAgXCJFcnJvciAtIEV4dHJhIEFyZ3MgYWZ0ZXIgbG9hZENTViB0aGF0IGlzIG5vdCAnaGVhZGVyJ1wiLFxuICAgICAgICAgICAgXSxcbiAgICAgICAgICBdO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBpZiAoZmlsZVBhdGggaW4gbW9ja2VkRGF0YU1hcCkge1xuICAgICAgICBpZiAoaXNIZWFkZXJDb3B5KSB7XG4gICAgICAgICAgY29uc3QgW2hlYWRlciwgLi4ucmVzdF0gPSBtb2NrZWREYXRhTWFwW2ZpbGVQYXRoXTtcbiAgICAgICAgICBzZXRIZWFkZXIoaGVhZGVyKTtcbiAgICAgICAgICBzZXRDc3ZEYXRhKHJlc3QpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHNldENzdkRhdGEobW9ja2VkRGF0YU1hcFtmaWxlUGF0aF0pO1xuICAgICAgICB9XG4gICAgICAgIHNldEZpbGVQYXRoKGZpbGVQYXRoKTtcbiAgICAgICAgc2V0Y3N2bG9hZCh0cnVlKTtcbiAgICAgICAgcmV0dXJuIFtbXCJDU1YgU3VjY2Vzc2Z1bGx5IExvYWRlZFwiXV07XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBzZXRJc0hlYWRlcihmYWxzZSk7XG4gICAgICAgIHJldHVybiBbW2BFcnJvciAtICR7ZmlsZVBhdGh9IG5vdCBwcmVzZW50YF1dO1xuICAgICAgfVxuICAgIH1cblxuICAgIC8vIEhhbmRsZSB0aGUgJ3ZpZXcnIGNvbW1hbmQgYW5kIGRpc3BsYXkgdGhlIGxvYWRlZCBDU1YgZGF0YVxuICAgIGZ1bmN0aW9uIGhhbmRsZVZpZXdDb21tYW5kKGFyZ3M6IHN0cmluZ1tdKSB7XG4gICAgICBpZiAoIWNzdmxvYWRlZCkge1xuICAgICAgICByZXR1cm4gW1tcIkVycm9yIC0gTm8gQ1NWIExvYWRlZFwiXV07XG4gICAgICB9XG4gICAgICBpZiAoYXJncy5sZW5ndGggIT09IDApIHtcbiAgICAgICAgcmV0dXJuIFtbXCJFcnJvciAtIFZpZXcgU2hvdWxkIE5vdCBJbmNsdWRlIE90aGVyIEFyZ3NcIl1dO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmV0dXJuIFtoZWFkZXIsIC4uLmNzdmRhdGFdO1xuICAgICAgfVxuICAgIH1cblxuICAgIC8vIEhhbmRsZSB0aGUgJ3NlYXJjaCcgY29tbWFuZCBhbmQgcGVyZm9ybSBhIHNlYXJjaCBvbiB0aGUgbG9hZGVkIENTViBkYXRhXG4gICAgZnVuY3Rpb24gaGFuZGxlU2VhcmNoQ29tbWFuZChhcmdzOiBzdHJpbmdbXSkge1xuICAgICAgaWYgKCFjc3Zsb2FkZWQpIHtcbiAgICAgICAgcmV0dXJuIFtbXCJFcnJvciAtIE5vIENTViBMb2FkZWRcIl1dO1xuICAgICAgfVxuICAgICAgaWYgKGFyZ3MubGVuZ3RoIDwgMikge1xuICAgICAgICByZXR1cm4gW1xuICAgICAgICAgIFtcIkVycm9yIC0gVG9vIEZldyBBcmd1bWVudHMsIEFkZCBhIDxjb2x1bW4+IGFuZCA8dmFsdWU+IHRvIHNlYXJjaFwiXSxcbiAgICAgICAgXTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnN0IFtjb2x1bW4sIHZhbHVlLCAuLi5yZXN0XSA9IGFyZ3M7XG4gICAgICAgIGlmIChyZXN0Lmxlbmd0aCAhPT0gMCkge1xuICAgICAgICAgIHJldHVybiBbW1wiRXJyb3IgLSBEbyBOb3QgRW50ZXIgQXJncyBPdGhlciBUaGFuIENvbHVtbiBhbmQgVmFsdWVcIl1dO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHJldHVybiBtb2NrZWRTZWFyY2hSZXN1bHRzW2ZpbGVQYXRoU2VhcmNoICsgXCItcmVzdWx0c1wiXTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJyZXBsLWlucHV0XCI+XG4gICAgICA8ZmllbGRzZXQ+XG4gICAgICAgIDxsZWdlbmQ+RW50ZXIgYSBjb21tYW5kOjwvbGVnZW5kPlxuICAgICAgICA8Q29udHJvbGxlZElucHV0XG4gICAgICAgICAgdmFsdWU9e2NvbW1hbmRTdHJpbmd9XG4gICAgICAgICAgc2V0VmFsdWU9e3NldENvbW1hbmRTdHJpbmd9XG4gICAgICAgICAgYXJpYUxhYmVsPXtcIkNvbW1hbmQgaW5wdXRcIn1cbiAgICAgICAgLz5cbiAgICAgIDwvZmllbGRzZXQ+XG4gICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IGhhbmRsZVN1Ym1pdChjb21tYW5kU3RyaW5nKX0+XG4gICAgICAgIFN1Ym1pdHRlZCB7Y291bnR9IHRpbWVzXG4gICAgICA8L2J1dHRvbj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL3RpZmZuZXlhaW5hL0NTMzIvbW9jay1qc3RpZmVsMS10YWluYTEvbW9jay9zcmMvY29tcG9uZW50cy9SRVBMSW5wdXQudHN4In0=